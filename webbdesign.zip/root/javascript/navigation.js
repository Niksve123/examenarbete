// Check for dark mode preference in localStorage
const isDarkMode = localStorage.getItem('darkMode') === 'true'; // Retrieve the dark mode status

// Apply dark mode class if it was previously set
if (isDarkMode) {
    document.body.classList.add('dark-mode'); // Apply dark mode class
}

// Fetch the navigation HTML and set up the event listeners
fetch('navigation.html')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        return response.text();
    })
    .then(data => {
        document.getElementById('navigation').innerHTML = data;

        const mobileIcon = document.getElementById('mobileIcon');
        const mobileNavContainer = document.querySelector('.mobileNavigation-Container');
        const menuIcon = document.getElementById('menuIcon');
        const mobileNavigationContent = document.querySelector('.mobileNavigation-content');
        const heroSection = document.querySelector('.heroSection');
        const alltingor = document.querySelector('.alltingor-container');
        const erbjudandenSektion = document.querySelector('.erbjudanden-sektion');
        const trustpilotlogo = document.getElementById('trustpilot-logo');

        // New references for the divider SVG and tjanster-container
        const dividerSVG = document.querySelector('.divider svg');
        const svgPath2 = document.getElementById('svgPath2');
        const tjansterContainer = document.querySelector('.tjanster-container');

        // Dark mode and light mode toggle elements
        const toggleDarkModeMobile = document.getElementById('toggleDarkModeMobile');
        const toggleIconDarkmodeMobile = document.getElementById('toggleIconDarkmodeMobile');
        const toggleIcon = document.getElementById('toggleIcon');
        const toggleIconColor = document.getElementById('toggleIconColor');

        
        // Function to toggle dark mode
        function toggleDarkMode(event) {
            event.preventDefault();

            document.body.classList.toggle('dark-mode');
            const isDarkMode = document.body.classList.contains('dark-mode');
            
            // Store the dark mode preference in localStorage
            localStorage.setItem('darkMode', isDarkMode); // Save preference

            // Change icon for mobile
            toggleIconDarkmodeMobile.classList.toggle('fa-moon', !isDarkMode);
            toggleIconDarkmodeMobile.classList.toggle('fa-sun', isDarkMode);
            document.getElementById('darkmodeMobileText').textContent = isDarkMode ? 'Ljust läge' : 'Mörkt läge';

            // Change icon for desktop
            toggleIconColor.classList.toggle('fa-moon', !isDarkMode);
            toggleIconColor.classList.toggle('fa-sun', isDarkMode);

            // Change SVG fill color based on mode
            dividerSVG.setAttribute('fill', isDarkMode ? '#000000' : '#F7F5F2');
            svgPath2.setAttribute('fill', isDarkMode ? '#000000' : '#F7F5F2');
            
            // Update tjanster-container background color
            tjansterContainer.style.backgroundColor = isDarkMode ? '#000000' : '#F7F5F2'; // Dark mode background vs light mode background
            
            // Update backgrounds of sections
            updateBackgrounds();
        }

        // Function to update the section backgrounds
        function updateBackgrounds() {
            const isDarkMode = document.body.classList.contains('dark-mode');

            // Update heroSection background
            const heroLightImage = '../../assets/hero-background-stad-comic-stil.webp';
            const heroDarkImage = '../../assets/hero-background-stad-comic-stil-darkmode.webp';
            heroSection.style.backgroundImage = `url(${isDarkMode ? heroDarkImage : heroLightImage})`;

            // Update erbjudanden-sektion background
            const erbjudandenLightImage = '../../assets/berakna-pris-hemsida-bg.webp';
            const erbjudandenDarkImage = '../../assets/berakna-pris-hemsida-darkmode-bg.webp';
            erbjudandenSektion.style.backgroundImage = `url(${isDarkMode ? erbjudandenDarkImage : erbjudandenLightImage})`;

            // Update Allting ingår background
            const alltingorLight = '../../assets/webbyra-hemsidor-design-light.webp';
            const alltingorDark = '../../assets/webbyra-hemsidor-design-dark.webp';
            alltingor.style.backgroundImage = `url(${isDarkMode ? alltingorDark : alltingorLight})`;

            // Update video sources and posters
            const videosourcelight = '../../assets/Weebey-video-light.webm';
            const videosourcedark = '../../assets/Weebey-video-dark.webm';
            const lightPoster = 'assets/thumbnail-light.webp';
            const darkPoster = 'assets/thumbnail-dark.webp';
            const videoElement = document.getElementById('WeebeyVideo'); // Make sure this is your video element

            // Assign the correct source and poster based on mode
            videoElement.src = isDarkMode ? videosourcedark : videosourcelight;
            videoElement.poster = isDarkMode ? darkPoster : lightPoster;

            // Optionally, load the video to apply the new source and poster
            videoElement.load();

            // Change the Trustpilot logo source based on the mode
            trustpilotlogo.src = isDarkMode ? '../../assets/trustpilot-vit.webp' : '../../assets/trustpilot.webp';
        }

        // Apply initial backgrounds based on current mode
        updateBackgrounds();

        // Mobile menu interactions
        mobileIcon.addEventListener('click', function(event) {
            event.preventDefault();
            mobileNavContainer.classList.toggle('expanded');
            menuIcon.classList.toggle('fa-bars');
            menuIcon.classList.toggle('fa-times');
            menuIcon.classList.toggle('spin');

            if (menuIcon.classList.contains('fa-times')) {
                menuIcon.style.color = '#082848';
                setTimeout(() => {
                    mobileNavigationContent.style.display = 'flex';
                    mobileNavigationContent.style.opacity = 1;

                    // Disable body scroll
                    document.body.classList.add('no-scroll');
                }, 500);
            } else {
                menuIcon.style.color = '';
                mobileNavigationContent.style.opacity = 0; // Change opacity immediately

                // Enable body scroll
                document.body.classList.remove('no-scroll');
            }
        });

        // Add scroll check for mobile icon color change
        const scrollCheck = () => {
            const sectionRect = heroSection.getBoundingClientRect();
            if (sectionRect.bottom < 0) {
                mobileIcon.style.color = '#082848';
            } else {
                mobileIcon.style.color = 'white';
            }
        };

        window.addEventListener('scroll', scrollCheck);
        scrollCheck(); // Initial check

        // Add event listeners for dark mode toggle
        toggleDarkModeMobile.addEventListener('click', toggleDarkMode);
        toggleIcon.addEventListener('click', toggleDarkMode);

        // Adding event listeners for button clicks
        document.getElementById('tjansterBtn').addEventListener('click', function() {
            const sublist1 = document.getElementById('sub-list-1');
            sublist1.style.display = sublist1.style.display === 'block' ? 'none' : 'block';
        });

        document.getElementById('fordigsomBtn').addEventListener('click', function() {
            const sublist2 = document.getElementById('sub-list-2');
            sublist2.style.display = sublist2.style.display === 'block' ? 'none' : 'block';
        });

        document.getElementById('academyBtn').addEventListener('click', function() {
            const sublist3 = document.getElementById('sub-list-3');
            sublist3.style.display = sublist3.style.display === 'block' ? 'none' : 'block';
        });

        // Function to toggle dropdown visibility
        function toggleSublist(activeSublistId) {
            const sublists = ['desktopsub-list-1', 'desktopsub-list-2', 'desktopsub-list-3'];
            sublists.forEach(sublistId => {
                const sublist = document.getElementById(sublistId);
                if (sublistId === activeSublistId) {
                    sublist.style.display = sublist.style.display === 'flex' ? 'none' : 'flex';
                } else {
                    sublist.style.display = 'none';
                }
            });
        }

        // Function to hide all sublists
        function hideAllSublists() {
            const sublists = ['desktopsub-list-1', 'desktopsub-list-2', 'desktopsub-list-3'];
            sublists.forEach(sublistId => {
                document.getElementById(sublistId).style.display = 'none';
            });
        }

        // Adding event listeners for button clicks for desktop dropdowns
        document.getElementById('desktopsub-list-1btn').addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            toggleSublist('desktopsub-list-1');
        });

        document.getElementById('desktopsub-list-2btn').addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            toggleSublist('desktopsub-list-2');
        });

        document.getElementById('desktopsub-list-3btn').addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            toggleSublist('desktopsub-list-3');
        });

        // Click event listener for closing dropdowns when clicking outside
        document.addEventListener('click', function(event) {
            const sublists = ['desktopsub-list-1', 'desktopsub-list-2', 'desktopsub-list-3'];

            const isInsideDropdown = sublists.some(sublistId => 
                event.target.closest(`#${sublistId}`) || event.target.matches(`#${sublistId}-btn`)
            );

            if (!isInsideDropdown) {
                hideAllSublists();
            }
        });

        // Function to hide all sublists on window resize
        function handleResize() {
            if (window.innerWidth <= 1300) {
                hideAllSublists();
            }
        }

        // Initial check for window size
        handleResize();

        // Resize event listener
        window.addEventListener('resize', handleResize);

        // New code for search toggle
        const toggleSearch = document.getElementById('toggleSearch');
        const toggleSearchMobile = document.getElementById('toggleSearchMobile'); // New mobile toggle
        const navLinks = document.querySelectorAll('.navLink, #navButton, .navIcons');
        const searchContainer = document.querySelector('.search-container');

        // Initialize a variable to track the search state
        let isSearchActive = false;

        // Function to handle the opening of the search container
        const openSearch = () => {
            isSearchActive = true; // Set search active state
            navLinks.forEach(link => {
                link.style.display = 'none';
            });
            searchContainer.style.display = 'flex';

            const elements = document.querySelectorAll('.desktopsub-list');
            elements.forEach(element => {
                element.style.display = 'none';
            });
        };

        // Function to handle the closing of the search container and icon visibility
        const closeSearch = () => {
            navLinks.forEach(link => {
                link.style.display = ''; // Reset to default display
            });
            searchContainer.style.display = 'none'; // Hide the search container
            isSearchActive = false; // Reset search active state
        };

        // Add click event listener for toggleSearch
        toggleSearch.addEventListener('click', function(event) {
            event.stopPropagation(); // Prevent click from bubbling up to the document
            event.preventDefault();
            openSearch(); // Call the function to open search
        });

        // Add click event listener for toggleSearchMobile
        toggleSearchMobile.addEventListener('click', function(event) {
            event.stopPropagation(); // Prevent click from bubbling up to the document
            event.preventDefault();
            openSearch(); // Call the function to open search
        });

        // Add click event listener for document to handle clicks outside the search container
        document.addEventListener('click', function(event) {
            if (isSearchActive && !searchContainer.contains(event.target) && event.target !== toggleSearch && event.target !== toggleSearchMobile) {
                closeSearch(); // Call the close search function
            }
        });


    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
        console.log('Failed to fetch navigation.html. Check the path or server status.');
        document.getElementById('navigation').innerHTML = '<p>Navigation could not be loaded. Please try again later.</p>';
    });