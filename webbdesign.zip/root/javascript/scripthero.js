// SCRIPT för att skapa en typande effekt
    
            const phrases = ["hemsida ", "Webbshop ", "Logotyp ", "SEO "]; // Listan med fraser som ska typas
            const typedTextElement = document.getElementById("typed-text");
            const cursorElement = document.querySelector(".cursor");
            let phraseIndex = 0; // Håller koll på aktuell fras
            let currentIndex = 0; // Håller koll på aktuell positionen i frasen

            function typeLetter() {
                if (currentIndex < phrases[phraseIndex].length) {
                    // S:-iv ut en bokstav
                    typedTextElement.innerHTML = `<span>Fixar din</span><br> ${phrases[phraseIndex].substring(0, currentIndex)}<span class='cursor'> </span><br>`;
                    currentIndex++;
                    setTimeout(typeLetter, 100); // 0.1 sek båda
                } else {
                    // När hela frasen har s:-ivits
                    setTimeout(() => {
                        // Väntar en sekund innan texten rensas
                        setTimeout(() => {
                            currentIndex = 0; // Nollställ position
                            phraseIndex = (phraseIndex + 1) % phrases.length; // Gå till nästa fras och loopa
                            // Starta typningen av nästa fras
                            typeLetter();
                        }, 1500); // Väntar 1 sek innan vi börjar om
                    }, 1500); // Väntar 1 sekund innan vi börjar s:-iva på nytt
                }
            }

            // Starta typning när s:-iptet laddas
            typeLetter();
        

//Flyggan superhjälte

const heroImageContainer = document.querySelector('.heroimagecontainer');
const flyawaySound = document.getElementById('flyaway-sound');
const raknautdittpris = document.getElementById('raknautdittpris');

// Set the volume to 50%
flyawaySound.volume = 0.5;

raknautdittpris.addEventListener('click', () => {
    // Play the sound
    flyawaySound.play();

    // Function to trigger the fly-out animation
    const triggerFlyOut = () => {
        // Store the current scroll position
        const currentScrollPosition = window.scrollY;

        // Add the fly-out class
        heroImageContainer.classList.add('fly-out');

        // Remove the container from the DOM after the animation completes
        setTimeout(() => {
            // Set the display to 'none' after the animation ends
            heroImageContainer.style.display = 'flex';

        }, 1500); // 1500 ms = 1.5 seconds
    };

    // Check if the container is currently animated (as in flying out)
    if (heroImageContainer.classList.contains('fly-out')) {
        // Reset the display and remove the fly-out class
        heroImageContainer.classList.remove('fly-out'); // Remove class to reset animation
        void heroImageContainer.offsetWidth; // Trigger reflow
        heroImageContainer.style.display = 'flex'; // Reset display
        triggerFlyOut(); // Call the function to start the animation again
    } else {
        triggerFlyOut(); // Call the function to start the animation
    }
});


//DIV BLIR BUBBLA
// Startar observationen av delaren
const divider = document.querySelector('.divider');
observer.observe(divider);