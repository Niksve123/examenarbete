// Check for dark mode preference in localStorage
const isDarkMode = localStorage.getItem('darkMode') === 'true'; // Retrieve the dark mode status

// Apply dark mode class if it was previously set
if (isDarkMode) {
    document.body.classList.add('dark-mode'); // Apply dark mode class
}


// Fetch the navigation HTML and set up the event listeners
fetch('navigation.html')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        return response.text();
    })
    .then(data => {
        document.getElementById('navigation').innerHTML = data;

        const mobileIcon = document.getElementById('mobileIcon');
        const mobileNavContainer = document.querySelector('.mobileNavigation-Container');
        const menuIcon = document.getElementById('menuIcon');
        const mobileNavigationContent = document.querySelector('.mobileNavigation-content');

        const toggleDarkModeMobile = document.getElementById('toggleDarkModeMobile');
        const toggleIconDarkmodeMobile = document.getElementById('toggleIconDarkmodeMobile');
        const toggleIconColor = document.getElementById('toggleIconColor');

        // Function to toggle dark mode
        function toggleDarkMode(event) {
            event.preventDefault();
            document.body.classList.toggle('dark-mode');
            const isDarkMode = document.body.classList.contains('dark-mode');

            // Store the dark mode preference in localStorage
            localStorage.setItem('darkMode', isDarkMode); // Save preference
            
            // Change icon for mobile
            toggleIconDarkmodeMobile.classList.toggle('fa-moon', !isDarkMode);
            toggleIconDarkmodeMobile.classList.toggle('fa-sun', isDarkMode);
            document.getElementById('darkmodeMobileText').textContent = isDarkMode ? 'Ljust läge' : 'Mörkt läge';

            // Change icon for desktop
            toggleIconColor.classList.toggle('fa-moon', !isDarkMode);
            toggleIconColor.classList.toggle('fa-sun', isDarkMode);
        }

         // Mobile menu interactions
mobileIcon.addEventListener('click', function(event) {
    event.preventDefault();
    
    mobileNavContainer.classList.toggle('expanded');
    menuIcon.classList.toggle('fa-bars');
    menuIcon.classList.toggle('fa-times');
    menuIcon.classList.toggle('spin');

    // Change icon color based on the newly toggled class
    if (menuIcon.classList.contains('fa-times')) {
        menuIcon.style.color = '#082848';
        setTimeout(() => {
            mobileNavigationContent.style.display = 'flex';
            mobileNavigationContent.style.opacity = 1;

            // Disable body scroll
            document.body.classList.add('no-scroll');
        }, 500);
    } else {
        menuIcon.style.color = '';
        mobileNavigationContent.style.opacity = 0; // Change opacity immediately

        // Enable body scroll
        document.body.classList.remove('no-scroll');
    }
    
});



            // Adding event listeners for button clicks
            document.getElementById('tjansterBtn').addEventListener('click', function() {
                const sublist1 = document.getElementById('sub-list-1');
                sublist1.style.display = sublist1.style.display === 'block' ? 'none' : 'block';
            });
    
            document.getElementById('fordigsomBtn').addEventListener('click', function() {
                const sublist2 = document.getElementById('sub-list-2');
                sublist2.style.display = sublist2.style.display === 'block' ? 'none' : 'block';
            });
    
            document.getElementById('academyBtn').addEventListener('click', function() {
                const sublist3 = document.getElementById('sub-list-3');
                sublist3.style.display = sublist3.style.display === 'block' ? 'none' : 'block';
            });
    
    
                       // Function to toggle dropdown visibility
    function toggleSublist(activeSublistId) {
        const sublists = ['desktopsub-list-1', 'desktopsub-list-2', 'desktopsub-list-3'];
        
        sublists.forEach(sublistId => {
            const sublist = document.getElementById(sublistId);
            // Hide the sublist if it's not the active one
            if (sublistId === activeSublistId) {
                sublist.style.display = sublist.style.display === 'flex' ? 'none' : 'flex';
            } else {
                sublist.style.display = 'none';
            }
        });
    }
    
    // Function to hide all sublists
    function hideAllSublists() {
        const sublists = ['desktopsub-list-1', 'desktopsub-list-2', 'desktopsub-list-3'];
        sublists.forEach(sublistId => {
            document.getElementById(sublistId).style.display = 'none';
        });
    }
    
    // Adding event listeners for button clicks
    document.getElementById('desktopsub-list-1btn').addEventListener('click', function(event) {
        event.stopPropagation(); // Prevent click event from bubbling up
        event.preventDefault();
        toggleSublist('desktopsub-list-1');
    });
    
    document.getElementById('desktopsub-list-2btn').addEventListener('click', function(event) {
        event.stopPropagation(); // Prevent click event from bubbling up
        event.preventDefault();
        toggleSublist('desktopsub-list-2');
    });
    
    document.getElementById('desktopsub-list-3btn').addEventListener('click', function(event) {
        event.stopPropagation(); // Prevent click event from bubbling up
        event.preventDefault();
        toggleSublist('desktopsub-list-3');
    });
    
    // Click event listener for closing dropdowns when clicking outside
    document.addEventListener('click', function(event) {
        const sublists = ['desktopsub-list-1', 'desktopsub-list-2', 'desktopsub-list-3'];
    
        // Check if the clicked element is not one of the dropdown buttons or their sublists
        const isInsideDropdown = sublists.some(sublistId => 
            event.target.closest(`#${sublistId}`) || event.target.matches(`#${sublistId}-btn`)
        );
    
        if (!isInsideDropdown) {
            // Hide all sublists
            hideAllSublists();
        }
    });
    
    // Function to hide all sublists on window resize
    function handleResize() {
        if (window.innerWidth <= 1300) {
            hideAllSublists();
        }
    }
    
    // Initial check for window size
    handleResize();
    
    // Resize event listener
    window.addEventListener('resize', handleResize);

        // Add event listeners for dark mode toggle
        toggleDarkModeMobile.addEventListener('click', toggleDarkMode);
        toggleIconColor.addEventListener('click', toggleDarkMode);



         // New code for search toggle
         const toggleSearch = document.getElementById('toggleSearch');
         const toggleSearchMobile = document.getElementById('toggleSearchMobile'); // New mobile toggle
         const navLinks = document.querySelectorAll('.navLink, #navButton, .navIcons');
         const searchContainer = document.querySelector('.search-container');
 
         // Initialize a variable to track the search state
         let isSearchActive = false;
 
         // Function to handle the opening of the search container
         const openSearch = () => {
             isSearchActive = true; // Set search active state
             // Set the display style for nav links, nav button, and icons
             navLinks.forEach(link => {
                 link.style.display = 'none';
             });
             // Set display style for search container
             searchContainer.style.display = 'flex';
 
             const elements = document.querySelectorAll('.desktopsub-list');
 
             // Loop through each element and set its display style to 'none'
             elements.forEach(element => {
                 element.style.display = 'none';
             });
         };
 
         // Function to handle the closing of the search container and icon visibility
         const closeSearch = () => {
             // Reset display styles if clicked outside search container and toggleSearch
             navLinks.forEach(link => {
                 link.style.display = ''; // Reset to default display
             });
 
             searchContainer.style.display = 'none'; // Hide the search container
 
             isSearchActive = false; // Reset search active state
         };
 
         // Add click event listener for toggleSearch
         toggleSearch.addEventListener('click', function(event) {
             event.stopPropagation(); // Prevent click from bubbling up to the document
             event.preventDefault();
             openSearch(); // Call the function to open search
         });
 
         // Add click event listener for toggleSearchMobile
         toggleSearchMobile.addEventListener('click', function(event) {
             event.stopPropagation(); // Prevent click from bubbling up to the document
             event.preventDefault();
             openSearch(); // Call the function to open search
         });
 
         // Add click event listener for document to handle clicks outside the search container
         document.addEventListener('click', function(event) {
             if (isSearchActive && !searchContainer.contains(event.target) && event.target !== toggleSearch && event.target !== toggleSearchMobile) {
                 closeSearch(); // Call the close search function
             }
         });

    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
        document.getElementById('navigation').innerHTML = '<p>Navigation could not be loaded. Please try again later.</p>';
    });