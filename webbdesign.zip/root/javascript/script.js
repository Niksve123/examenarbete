const path = document.getElementById('svgPath');
const scrollicon = document.querySelector('.scrollicon');

const newPath = 'M0 100v-4c250 0 350-96 500-96S750 96 1000 96V200H0Z';
let pathChanged = false;
let lastScrollTop = 0;

// Observer for SVG-path change
const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            setTimeout(() => {
                path.setAttribute('d', newPath);
                pathChanged = true;
                setTimeout(() => {
                    scrollicon.classList.add('visible');
                }, 900);
                observer.unobserve(entry.target);
                window.addEventListener('scroll', changeImageOnScroll);
            }, 200);
        }
    });
});

// Scroll event function to change image based on scroll direction
function changeImageOnScroll() {
    const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollicon = document.querySelector('.scrollicon'); // Ensure you select the correct element

    // Check if dark mode is active
    const isDarkMode = document.body.classList.contains('dark-mode');

    if (currentScrollTop > lastScrollTop) {
        // Scrolling down
        scrollicon.src = isDarkMode ? 'assets/scroll-icon-vit-2.webp' : 'assets/scroll-icon-svart.webp'; // Change image based on mode
    } else {
        // Scrolling up
        scrollicon.src = isDarkMode ? 'assets/scroll-icon-vit.webp' : 'assets/scroll-icon-svart-2.webp'; // Change back based on mode
    }
    
    // Update lastScrollTop for the next scroll event
    lastScrollTop = currentScrollTop <= 0 ? 0 : currentScrollTop; // For Mobile or negative scrolling
}

// Ensure to bind this function to the scroll event
window.addEventListener('scroll', changeImageOnScroll);

// Smoothly scroll to price element
function scrollToPrice() {
    const element = document.getElementById("pris");
    if (element) {
        setTimeout(() => {
            element.scrollIntoView({ behavior: 'smooth' }); // Smoothly scroll to the element after a 1-second delay
        }, 1000); // Delay of 1000 milliseconds (1 second)
    }
}







document.addEventListener('DOMContentLoaded', function () {
    const checkboxes = document.querySelectorAll('.custom-checkbox');
    const reviewItems = document.querySelectorAll('.review-item');
    const noReviewsMessage = document.getElementById('no-reviews-message');
    const reviewContent = document.querySelector('.review-content');
    const dotsContainer = document.getElementById('dotsContainer');

    let activeDotIndex = 0; // To track the currently active dot

    function updateReviewVisibility() {
        const selectedRatings = Array.from(checkboxes)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.getAttribute('data-rating'));

        let hasVisibleReviews = false;

        reviewItems.forEach(item => {
            const stars = item.querySelectorAll('.review-item-stars .fas.fa-star').length;

            // Show or hide the review based on selected ratings
            if (selectedRatings.includes(stars.toString())) {
                item.style.display = 'block';
                hasVisibleReviews = true; // At least one review is visible
            } else {
                item.style.display = 'none';
            }
        });

        // Show or hide the "no reviews" message
        noReviewsMessage.style.display = hasVisibleReviews ? 'none' : 'flex'; // Show message

        // Update dots based on visible reviews
        updateDots();
    }

    function updateDots() {
        // Clear existing dots
        while (dotsContainer.firstChild) {
            dotsContainer.removeChild(dotsContainer.firstChild);
        }

        // Create dots dynamically based on visible review items
        const visibleItems = Array.from(reviewItems).filter(item => item.style.display === 'block');

        visibleItems.forEach((item, index) => {
            const dot = document.createElement('div');
            dot.classList.add('dots-item');

            // Set background color for the active dot
            if (index === activeDotIndex) {
                dot.style.backgroundColor = '#082848'; // Active color
            }

            dot.addEventListener('click', () => {
                // Set all dots back to original color
                const allDots = dotsContainer.children;
                Array.from(allDots).forEach(d => {
                    d.style.backgroundColor = 'white'; // Reset color
                });

                // Update the active index
                activeDotIndex = index;

                // Set the clicked dot to active color
                dot.style.backgroundColor = '#082848'; // Active color

                // Calculate offset for scrolling
                const offset = Array.from(reviewItems).indexOf(item) * (item.offsetWidth + 20); // width + spacing
                reviewContent.style.transform = `translateX(-${offset}px)`; // Translate the container
            });

            dotsContainer.appendChild(dot);
        });
    }

    // Add event listeners to all checkboxes
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateReviewVisibility);
    });

    // Initialize the visibility state based on the checked state of checkboxes
    updateReviewVisibility();
});


// Get the video element and buttons
const videoElement = document.getElementById('WeebeyVideo');
const playButton = document.getElementById('playButton');
const pauseButton = document.getElementById('pauseButton');
const muteButton = document.getElementById('muteButton');
const soundButton = document.getElementById('soundButton');
const restartButton = document.getElementById('restartButton');
const fullScreenButton = document.getElementById('fullScreenButton');

// Add event listeners to the buttons
playButton.addEventListener('click', () => {
    videoElement.play();
    playButton.style.display = 'none';
    pauseButton.style.display = 'flex';
});

pauseButton.addEventListener('click', () => {
    videoElement.pause();
    pauseButton.style.display = 'none';
    playButton.style.display = 'flex';
});




// Set the initial state of the buttons
muteButton.style.display = 'flex';
soundButton.style.display = 'none';

// Add event listeners to the buttons
muteButton.addEventListener('click', () => {
    videoElement.muted = true; // Mute the video
    muteButton.style.display = 'none'; // Hide the mute button
    soundButton.style.display = 'flex'; // Show the sound button
});

soundButton.addEventListener('click', () => {
    videoElement.muted = false; // Unmute the video
    muteButton.style.display = 'flex'; // Show the mute button
    soundButton.style.display = 'none'; // Hide the sound button
});

restartButton.addEventListener('click', () => {
    videoElement.currentTime = 0;
    videoElement.play();
    playButton.style.display = 'none';
    pauseButton.style.display = 'flex';
});

fullScreenButton.addEventListener('click', () => {
    if (document.fullscreenElement) {
        document.exitFullscreen();
    } else {
        videoElement.requestFullscreen();
    }
});


