// Function to count up to a given target value
function countUp(target, duration) {
    const countDisplay = document.getElementById('priskalkyl');
    const totalPrisDisplay = document.getElementById('totalPrisDisplay'); // Reference to the totalPrisDisplay element
    const start = parseInt(countDisplay.innerHTML, 10) || 0; // Current displayed value
    const change = target - start; // Total change needed
    const startTime = performance.now(); // Start time

    const animate = (currentTime) => {
        const timeElapsed = currentTime - startTime;
        const t = Math.min(timeElapsed / duration, 1); // Normalize to [0, 1]
        const increment = change * easeOutQuad(t);
        const newValue = Math.floor(start + increment); // Calculate new value

        countDisplay.innerHTML = newValue; // Update the countDisplay
        totalPrisDisplay.innerHTML = newValue; // Also update totalPrisDisplay

        if (t < 1) {
            requestAnimationFrame(animate);
        } else {
            countDisplay.innerHTML = target; // Ensure it ends exactly at target
            totalPrisDisplay.innerHTML = target; // Also ensure totalPrisDisplay ends at target
        }
    };

    requestAnimationFrame(animate); // Start animation
}

// Easing function example: easeOutQuad
function easeOutQuad(t) {
    return t * (2 - t);
}





// Variables to hold the heading values
let val2sHeading = '';
let val3sHeading = '';
let val4sHeading = '';
let val5sHeading = '';
let val6sHeading = '';
let val7sHeading = '';
let val8sHeading = '';
let val9sHeading = '';
let val11sHeading = '';

// Function to update the displayed headings
function updateDisplayedHeadings() {
    document.getElementById('paymentOption').textContent = val2sHeading || 'Inget val';
    document.getElementById('design').textContent = val3sHeading || 'Inget val';
    document.getElementById('subpages').textContent = val4sHeading || 'Inget val';
    document.getElementById('animations').textContent = val5sHeading || 'Inget val';
    document.getElementById('seo').textContent = val6sHeading || 'Inget val';
    document.getElementById('dashboard').textContent = val7sHeading || 'Inget val';
    document.getElementById('webshop').textContent = val8sHeading || 'Inget val';
    document.getElementById('termination').textContent = val9sHeading || 'Inget val';
    document.getElementById('template').textContent = val11sHeading || 'Inget val';  // Adjusted to the correct ID
}

// Generalized function to handle button clicks
function handleButtonClicked(button) {

        // Disable the button immediately
        button.disabled = true;

    const heading = button.dataset.heading;
    const buttonId = button.id;
    
    // Set the appropriate heading variable based on the button id
    if (buttonId.startsWith('val2')) {
        val2sHeading = heading;
    } else if (buttonId.startsWith('val3')) {
        val3sHeading = heading;
    } else if (buttonId.startsWith('val4')) {
        val4sHeading = heading;
    } else if (buttonId.startsWith('val5')) {
        val5sHeading = heading;
    } else if (buttonId.startsWith('val6')) {
        val6sHeading = heading;
    } else if (buttonId.startsWith('val7')) {
        val7sHeading = heading;
    } else if (buttonId.startsWith('val8')) {
        val8sHeading = heading;
    } else if (buttonId.startsWith('val9')) {
        val9sHeading = heading;
    } else if (buttonId.startsWith('val11')) {
        val11sHeading = heading;
    }

    // Update displayed headings
    updateDisplayedHeadings();
    
        // Re-enable the button after 1 second
        setTimeout(() => {
            button.disabled = false;
        }, 1000);
}

// Adding event listeners to all buttons
document.querySelectorAll('.mainButton').forEach(button => {
    button.addEventListener('click', function() {
        handleButtonClicked(this);
    });
});



// Initial values
let currentPrice = 0;
let addedValues = []; // To track added values for backtracking

// Function to handle button clicks
document.querySelectorAll('.val-pris .mainButton').forEach(button => {
    button.addEventListener('click', function() {
        const currentSection = button.closest('.val-pris');
        const currentId = currentSection.id;
        const buttonValue = parseInt(button.value, 10) || 0; // Get button value

        // Always add the buttonValue to currentPrice and addedValues
        currentPrice += buttonValue; // Update the total price
        addedValues.push(buttonValue); // Push value for potential backtracking
        console.log("Added Values: ", addedValues); // Log the current state of added values
        countUp(currentPrice, 500); // Update the displayed price

        // Handle section transitions
        const nextSectionId = getNextSectionId(currentId, button.id);
        if (nextSectionId) {
            transitionToNextSection(currentId, nextSectionId);
        }
    });
});

// Handle transition to the next section with animations
function transitionToNextSection(currentId, nextId) {
    const currentSection = document.getElementById(currentId);
    const nextSection = document.getElementById(nextId);

    currentSection.style.transition = 'transform 1s ease';
    currentSection.style.transform = 'translateX(-100%)'; // Slide out

    setTimeout(() => {
        currentSection.style.display = 'none';
        nextSection.style.display = 'flex';
        void nextSection.offsetWidth; // Trigger reflow
        nextSection.style.transform = 'translateX(0)'; // Slide in

        // After animation, navigate to the anchor "#pris"
        const anchor = document.querySelector('#currentPrice');

        if (anchor) {
            const scrollPosition = window.innerWidth < 1300 ? anchor.offsetTop - 20 : anchor.offsetTop - 100;
        
            window.scrollTo({ 
                top: scrollPosition, 
                behavior: 'smooth'
            });
        }
    }, 1000); // Match with animation duration
}

// Function to get the next section based on current section and button clicked
function getNextSectionId(currentId, buttonId) {
    const nextMap = {
        'val1': { 'val1-btn1': 'val2', 'val1-btn2': 'val2', 'val1-btn3': 'val2' },
        'val2': { 'val2-btn1': 'val3', 'val2-btn2': 'val3' },
        'val3': { 'val3-btn1': 'val11', 'val3-btn2': 'val4' },
        'val11': { 'val11-btn1': 'val4', 'val11-btn2': 'val4', 'val11-btn3': 'val4' },
        'val4': { 'val4-btn1': 'val5', 'val4-btn2': 'val5', 'val4-btn3': 'val5' },
        'val5': { 'val5-btn1': 'val6', 'val5-btn2': 'val6' },
        'val6': { 'val6-btn1': 'val7', 'val6-btn2': 'val7', 'val6-btn3': 'val7' },
        'val7': { 'val7-btn1': 'val8', 'val7-btn2': 'val8', 'val7-btn3': 'val8' },
        'val8': { 'val8-btn1': 'val9', 'val8-btn2': 'val9', 'val8-btn3': 'val9' },
        'val9': { 'val9-btn1': 'val10', 'val9-btn2': 'val10', 'val9-btn3': 'val10' },
        'val10': { 'val10-btn1': null, 'val10-btn2': null, 'val10-btn3': null } // No next
    };

    return nextMap[currentId][buttonId] || null; // Return next section ID or null
}

// Handle "Go Back" button functionality
document.querySelectorAll('.goBack').forEach(button => {
    button.addEventListener('click', function() {
        const currentSection = button.closest('.val-pris');
        const currentId = currentSection.id;
        const previousId = getPreviousSectionId(currentId);

        if (previousId) {
            const previousSection = document.getElementById(previousId);
            transitionToPreviousSection(currentSection, previousSection);
            
            // If there's any added value for backtracking
            if (addedValues.length > 0) {
                const lastValue = addedValues.pop(); // Remove last added value
                console.log("Removed Value: ", lastValue); // Log the removed value
                console.log("Current Added Values: ", addedValues); // Log the current state of added values
                currentPrice -= lastValue; // Subtract it from current price
                countUp(currentPrice, 500); // Update displayed price
            }
        }
    });
});

// Function to handle transitioning back to the previous section
function transitionToPreviousSection(currentSection, previousSection) {
    currentSection.style.transition = 'transform 1s ease';
    currentSection.style.transform = 'translateX(100%)'; // Slide out to the right

    setTimeout(() => {
        currentSection.style.display = 'none';
        previousSection.style.display = 'flex';
        void previousSection.offsetWidth; // Trigger reflow
        previousSection.style.transform = 'translateX(0)'; // Slide in from the left
    }, 1000); // Match with animation duration
}

// Function to get the previous section ID
function getPreviousSectionId(currentId) {
    const previousMap = {
        'val2': 'val1',
        'val3': 'val2',
        'val4': 'val3',
        'val5': 'val4',
        'val6': 'val5',
        'val7': 'val6',
        'val8': 'val7',
        'val9': 'val8',
        'val10': 'val9',
        'val11': 'val3'
    };

    // Hide the element if the current section is val3
    if (currentId === 'val3') {
        document.getElementById('ifAbbonemang').style.display = "none";
    }

    return previousMap[currentId] || null; // Return the previous ID or null
}

// Handling button clicks for price updates (val2 and val3 button functionalities)
document.getElementById('val2-btn1').addEventListener('click', function() {
    document.getElementById('ifAbbonemang').style.display = "none";
    document.getElementById('ifAbbonemang2').style.display = "none";
    document.getElementById('Startavgiftrubrik').style.display = "none";


    // Update values in MALL ELLER UNIK DESIGN
    document.getElementById('val3-pris1').innerHTML = "<strong>+ 0:-</strong>"; // No change for färdig mall
    document.getElementById('val3-btn1').value = 0; // Update button value
    document.getElementById('val3-pris2').innerHTML = "<strong>+ 2495:-</strong>"; // Change for unik design
    document.getElementById('val3-btn2').value = 2495; // Update button value

    // Update values in UNDERSIDOR
    document.getElementById('val4-pris1').innerHTML = "<strong>+ 0:-</strong>"; // Change for 2-5 undersidor
    document.getElementById('val4-btn1').value = 0; // Update button value
    document.getElementById('val4-pris2').innerHTML = "<strong>+ 2495:-</strong>"; // Change for 7-9 undersidor
    document.getElementById('val4-btn2').value = 2495; // Update button value
    document.getElementById('val4-pris3').innerHTML = "<strong>+ 3995:-</strong>"; // Change for 10 eller fler
    document.getElementById('val4-btn3').value = 3995; // Update button value

    // Update values in ANIMATIONER
    document.getElementById('val5-pris1').innerHTML = "<strong>+ 0:-</strong>"; // Change for Ja, tack
    document.getElementById('val5-btn1').value = 0; // Update button value
    document.getElementById('val5-pris2').innerHTML = "<strong>+ 695:-</strong>"; // No change for Nej, tack
    document.getElementById('val5-btn2').value = 695; // Update button value

    // Update values in SEO
    document.getElementById('val6-pris1').innerHTML = "<strong>+ 0:-</strong>"; // Change for Basis
    document.getElementById('val6-btn1').value = 0; // Update button value
    document.getElementById('val6-pris2').innerHTML = "<strong>+ 1795:-</strong>"; // Change for Plus
    document.getElementById('val6-btn2').value = 1795; // Update button value
    document.getElementById('val6-pris3').innerHTML = "<strong>+ 2495:-</strong>"; // Change for Premium
    document.getElementById('val6-btn3').value = 2495; // Update button value

    // Update values in DASHBOARD
    document.getElementById('val7-pris1').innerHTML = "<strong>+ 0:-</strong>"; // No change for Nej, tack
    document.getElementById('val7-btn1').value = 0; // Update button value
    document.getElementById('val7-pris2').innerHTML = "<strong>+ 2995:-</strong>"; // Change for En enkel
    document.getElementById('val7-btn2').value = 2995; // Update button value
    document.getElementById('val7-pris3').innerHTML = "<strong>+ 3795:-</strong>"; // Change for En avancerade
    document.getElementById('val7-btn3').value = 3795; // Update button value

    // Update values in WEBBSHOP
    document.getElementById('val8-pris1').innerHTML = "<strong>+ 0:-</strong>"; // No change for Nej, tack
    document.getElementById('val8-btn1').value = 0; // Update button value
    document.getElementById('val8-pris2').innerHTML = "<strong>+ 3495:-</strong>"; // Change for Ja, en liten
    document.getElementById('val8-btn2').value = 3495; // Update button value
    document.getElementById('val8-pris3').innerHTML = "<strong>+ 4995:-</strong>"; // Change for Ja, en stor
    document.getElementById('val8-btn3').value = 4995; // Update button value

    // Update values in UPPSÄGNING
    document.getElementById('val9-pris1').innerHTML = "<strong>ingen uppsägning</strong>"; // Change for 0 månader
    document.getElementById('val9-btn1').value = 0; // Update button value
    document.getElementById('val9-pris2').innerHTML = "<strong>ingen uppsägning</strong>"; // Change for 6 månader
    document.getElementById('val9-btn2').value = 0; // Update button value
    document.getElementById('val9-pris3').innerHTML = "<strong>ingen uppsägning</strong>"; // Change for 12 månader
    document.getElementById('val9-btn3').value = 0; // Update button value

});

document.getElementById('val2-btn2').addEventListener('click', function() {
    document.getElementById('ifAbbonemang').style.display = "inline";
    document.getElementById('ifAbbonemang2').style.display = "inline";
    document.getElementById('Startavgiftrubrik').style.display = "inline";

    document.getElementById('val3-pris1').innerHTML = "<strong>+ 0:-</strong>"; // No change for färdig mall
    document.getElementById('val3-btn1').value = 0; // Update button value
    document.getElementById('val3-pris2').innerHTML = "<strong>+ 49:-</strong>"; // Change for unik design
    document.getElementById('val3-btn2').value = 49; // Update button value

    // Update values in UNDERSIDOR
    document.getElementById('val4-pris1').innerHTML = "<strong>+ 0:-</strong>"; // Change for 2-5 undersidor
    document.getElementById('val4-btn1').value = 0; // Update button value
    document.getElementById('val4-pris2').innerHTML = "<strong>+ 59:-</strong>"; // Change for 7-9 undersidor
    document.getElementById('val4-btn2').value = 59; // Update button value
    document.getElementById('val4-pris3').innerHTML = "<strong>+ 89:-</strong>"; // Change for 10 eller fler
    document.getElementById('val4-btn3').value = 129; // Update button value

    // Update values in ANIMATIONER
    document.getElementById('val5-pris1').innerHTML = "<strong>+ 0:-</strong>"; // Change for Ja, tack
    document.getElementById('val5-btn1').value = 0; // Update button value
    document.getElementById('val5-pris2').innerHTML = "<strong>+ 49:-</strong>"; // No change for Nej, tack
    document.getElementById('val5-btn2').value = 49; // Update button value

    // Update values in SEO
    document.getElementById('val6-pris1').innerHTML = "<strong>+ 0:-</strong>"; // Change for Basis
    document.getElementById('val6-btn1').value = 0; // Update button value
    document.getElementById('val6-pris2').innerHTML = "<strong>+ 99:-</strong>"; // Change for Plus
    document.getElementById('val6-btn2').value = 99; // Update button value
    document.getElementById('val6-pris3').innerHTML = "<strong>+ 149:-</strong>"; // Change for Premium
    document.getElementById('val6-btn3').value = 149; // Update button value

    // Update values in DASHBOARD
    document.getElementById('val7-pris1').innerHTML = "<strong>+ 0:-</strong>"; // No change for Nej, tack
    document.getElementById('val7-btn1').value = 0; // Update button value
    document.getElementById('val7-pris2').innerHTML = "<strong>+ 79:-</strong>"; // Change for En enkel
    document.getElementById('val7-btn2').value = 79; // Update button value
    document.getElementById('val7-pris3').innerHTML = "<strong>+ 129:-</strong>"; // Change for En avancerade
    document.getElementById('val7-btn3').value = 129; // Update button value

    // Update values in WEBBSHOP
    document.getElementById('val8-pris1').innerHTML = "<strong>+ 0:-</strong>"; // No change for Nej, tack
    document.getElementById('val8-btn1').value = 0; // Update button value
    document.getElementById('val8-pris2').innerHTML = "<strong>+ 149:-</strong>"; // Change for Ja, en liten
    document.getElementById('val8-btn2').value = 149; // Update button value
    document.getElementById('val8-pris3').innerHTML = "<strong>+ 299:-</strong>"; // Change for Ja, en stor
    document.getElementById('val8-btn3').value = 299; // Update button value

    // Update values in UPPSÄGNING
    document.getElementById('val9-pris1').innerHTML = "<strong>+ 49:-</strong>"; // Change for 0 månader
    document.getElementById('val9-btn1').value = 49; // Update button value
    document.getElementById('val9-pris2').innerHTML = "<strong>+ 29:-</strong>"; // Change for 6 månader
    document.getElementById('val9-btn2').value = 29; // Update button value
    document.getElementById('val9-pris3').innerHTML = "<strong>+ 0:-</strong>"; // Change for 12 månader
    document.getElementById('val9-btn3').value = 0; // Update button value


});




//CIRKEL INFO
// Select all elements with the class 'infoCircle-pris'
const infoCirclePrisElements = document.querySelectorAll('.infoCircle-pris');

// Loop through each element
infoCirclePrisElements.forEach(infoCirclePris => {
    const heading = infoCirclePris.querySelector('h3');
    const paragraph = infoCirclePris.querySelector('p');
    const infobutton = infoCirclePris.querySelector('button');

    infoCirclePris.addEventListener('click', function () {
        infoCirclePris.classList.toggle('active');

        if (infoCirclePris.classList.contains('active')) {
            // Wait 150ms before displaying h3 and p
            setTimeout(function () {
                heading.style.display = 'block';
                paragraph.style.display = 'block';
                infobutton.style.display = 'block';
            }, 150);
        } else {
            // Immediately reset display to none when clicking to deactivate
            heading.style.display = 'none';
            paragraph.style.display = 'none';
            infobutton.style.display = 'none';
        }
    });

    // Hide on outside click
    document.addEventListener('click', function (event) {
        if (!infoCirclePris.contains(event.target) && infoCirclePris.classList.contains('active')) {
            infoCirclePris.classList.remove('active');
            heading.style.display = 'none';
            paragraph.style.display = 'none';
            infobutton.style.display = 'none';
        }
    });
});
    
