function openLogin() {
    window.open('https://www.brillianik.se/users/login.php', '_blank', 'noopener,noreferrer');
}