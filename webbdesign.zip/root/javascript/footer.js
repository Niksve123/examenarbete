// Hämtar footer från footer.html
fetch('footer.html')
    .then(response => {
        // Check if the response is okay (status in the range 200-299)
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.text();
    })
    .then(data => {
        document.getElementById('footer').innerHTML = data;
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
        document.getElementById('footer').innerHTML = '<p>Footer could not be loaded. Please try again later.</p>';
    });