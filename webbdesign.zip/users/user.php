<?php
session_start();
require 'db_connect.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check user access
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header("Location: login.php");
    exit();
}

// Get the user ID from the URL
if (isset($_GET['userID'])) {
    $userId = (int)$_GET['userID'];
    $sql = "SELECT * FROM users WHERE id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    
    // Check if the user exists
    if ($result->num_rows == 0) {
        die("User not found");
    }

    $user = $result->fetch_assoc();
} else {
    header("Location: admin.php");
    exit();
}

// Check if the update form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve checkbox data for features
    $abonnemang = isset($_POST['abonnemang']) ? 1 : 0;
    $fastpris = isset($_POST['fastpris']) ? 1 : 0;
    $mall = isset($_POST['mall']) ? 1 : 0;
    $simpel = isset($_POST['simpel']) ? 1 : 0;
    $stilren = isset($_POST['stilren']) ? 1 : 0;
    $modern = isset($_POST['modern']) ? 1 : 0;
    $unikdesign = isset($_POST['unikdesign']) ? 1 : 0;
    $undersidorliten = isset($_POST['undersidorliten']) ? 1 : 0;
    $undersidormellan = isset($_POST['undersidormellan']) ? 1 : 0;
    $undersidorstor = isset($_POST['undersidorstor']) ? 1 : 0;
    $animationer = isset($_POST['animationer']) ? 1 : 0;
    $seobasis = isset($_POST['seobasis']) ? 1 : 0;
    $seoplus = isset($_POST['seoplus']) ? 1 : 0;
    $seopremium = isset($_POST['seopremium']) ? 1 : 0;
    $dashboardingen = isset($_POST['dashboardingen']) ? 1 : 0;
    $dashboardlenkel = isset($_POST['dashboardlenkel']) ? 1 : 0;
    $dashboardavancerad = isset($_POST['dashboardavancerad']) ? 1 : 0;
    $webbshopingen = isset($_POST['webbshopingen']) ? 1 : 0;
    $webbshopliten = isset($_POST['webbshopliten']) ? 1 : 0;
    $webbshopstor = isset($_POST['webbshopstor']) ? 1 : 0;
    $uppsagningnoll = isset($_POST['uppsagningnoll']) ? 1 : 0;
    $uppsagningsex = isset($_POST['uppsagningsex']) ? 1 : 0;
    $uppsagningtolv = isset($_POST['uppsagningtolv']) ? 1 : 0;

    // Get the selected status from the POST request
    $status = isset($_POST['status']) ? (int)$_POST['status'] : 8; // Default to 7 (Ej godkänd)

    // Get the "hemsida" input from the form
    $hemsida = isset($_POST['hemsida']) ? trim($_POST['hemsida']) : '';

    // Calculate total price
    $totalPrice = 0;
    if ($abonnemang) $totalPrice += 299;
    if ($fastpris) $totalPrice += 3950;
    if ($mall) $totalPrice += 0; 
    if ($simpel) $totalPrice += 0; 
    if ($stilren) $totalPrice += 0; 
    if ($modern) $totalPrice += 0; 
    if ($unikdesign) $totalPrice += 49;
    if ($undersidorliten) $totalPrice += 0; 
    if ($undersidormellan) $totalPrice += 59;
    if ($undersidorstor) $totalPrice += 89;
    if ($animationer) $totalPrice += 49;
    if ($seobasis) $totalPrice += 0; 
    if ($seoplus) $totalPrice += 99;
    if ($seopremium) $totalPrice += 149; 
    if ($dashboardingen) $totalPrice += 0; 
    if ($dashboardlenkel) $totalPrice += 79;
    if ($dashboardavancerad) $totalPrice += 129;
    if ($webbshopingen) $totalPrice += 0; 
    if ($webbshopliten) $totalPrice += 149;
    if ($webbshopstor) $totalPrice += 299;
    if ($uppsagningnoll) $totalPrice += 49;
    if ($uppsagningsex) $totalPrice += 29;
    if ($uppsagningtolv) $totalPrice += 19;

// Prepare the SQL update statement
$sqlUpdate = "UPDATE users SET 
    abonnemang = ?, 
    fastpris = ?, 
    mall = ?, 
    simpel = ?, 
    stilren = ?, 
    modern = ?, 
    unikdesign = ?, 
    undersidorliten = ?, 
    undersidormellan = ?, 
    undersidorstor = ?, 
    animationer = ?, 
    seobasis = ?, 
    seoplus = ?, 
    seopremium = ?, 
    dashboardingen = ?, 
    dashboardlenkel = ?, 
    dashboardavancerad = ?, 
    webbshopingen = ?, 
    webbshopliten = ?, 
    webbshopstor = ?, 
    uppsagningnoll = ?, 
    uppsagningsex = ?, 
    uppsagningtolv = ?, 
    hemsida = ?, 
    price = ?, 
    status = ? 
    WHERE id = ?";

// Prepare the statement
$stmt = $conn->prepare($sqlUpdate);

// Bind parameters, including hemsida
$stmt->bind_param('iiiiiiiiiiiiiiiiiiiiiiisisi', 
    $abonnemang, $fastpris, $mall, $simpel, $stilren,
    $modern, $unikdesign, $undersidorliten, $undersidormellan,
    $undersidorstor, $animationer, $seobasis, $seoplus,
    $seopremium, $dashboardingen, $dashboardlenkel,
    $dashboardavancerad, $webbshopingen, $webbshopliten,
    $webbshopstor, $uppsagningnoll, $uppsagningsex, 
    $uppsagningtolv, $hemsida, $totalPrice, $status, $userId
);

    // Execute the statement
    if ($stmt->execute()) {
        header("Location: user.php?userID=$userId&msg=Updated Successfully");
        exit();
    } else {
        echo "Error updating record: " . $stmt->error; // Show error if any
    }

    $stmt->close(); // Close the statement
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - <?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        .edit-button {
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            text-decoration: none;
        }
        .select-status {
            width: 100%;
        }
    </style>
</head>
<body>
    <h1>User Management - <?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?></h1>
    
    <form method="POST" action="user.php?userID=<?php echo $userId; ?>">
        <table>
            <tr>
                <th>ID</th>
                <td><?php echo htmlspecialchars($user['id']); ?></td>
            </tr>
            <tr>
                <th>Name</th>
                <td><?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
            </tr>
            <tr>
                <th>Hemsida</th>  <!-- Added Hemsida input field -->
                <td><input type="text" name="hemsida" value="<?php echo htmlspecialchars(isset($user['hemsida']) ? $user['hemsida'] : ''); ?>" maxlength="255"></td>
            </tr>
            <tr>
                <th>Abonnemang</th>
                <td><input type="checkbox" name="abonnemang" <?php echo $user['abonnemang'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Fastpris</th>
                <td><input type="checkbox" name="fastpris" <?php echo $user['fastpris'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Mall</th>
                <td><input type="checkbox" name="mall" <?php echo $user['mall'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Simpel</th>
                <td><input type="checkbox" name="simpel" <?php echo $user['simpel'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Stilren</th>
                <td><input type="checkbox" name="stilren" <?php echo $user['stilren'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Modern</th>
                <td><input type="checkbox" name="modern" <?php echo $user['modern'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Unikdesign</th>
                <td><input type="checkbox" name="unikdesign" <?php echo $user['unikdesign'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Undersidor Liten</th>
                <td><input type="checkbox" name="undersidorliten" <?php echo $user['undersidorliten'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Undersidor Mellan</th>
                <td><input type="checkbox" name="undersidormellan" <?php echo $user['undersidormellan'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Undersidor Stor</th>
                <td><input type="checkbox" name="undersidorstor" <?php echo $user['undersidorstor'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Animationer</th>
                <td><input type="checkbox" name="animationer" <?php echo $user['animationer'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>SEO Basis</th>
                <td><input type="checkbox" name="seobasis" <?php echo $user['seobasis'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>SEO Plus</th>
                <td><input type="checkbox" name="seoplus" <?php echo $user['seoplus'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>SEO Premium</th>
                <td><input type="checkbox" name="seopremium" <?php echo $user['seopremium'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Dashboard Ingen</th>
                <td><input type="checkbox" name="dashboardingen" <?php echo $user['dashboardingen'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Dashboard Enkel</th>
                <td><input type="checkbox" name="dashboardlenkel" <?php echo $user['dashboardlenkel'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Dashboard Avancerad</th>
                <td><input type="checkbox" name="dashboardavancerad" <?php echo $user['dashboardavancerad'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Webbshop Ingen</th>
                <td><input type="checkbox" name="webbshopingen" <?php echo $user['webbshopingen'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Webbshop Liten</th>
                <td><input type="checkbox" name="webbshopliten" <?php echo $user['webbshopliten'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Webbshop Stor</th>
                <td><input type="checkbox" name="webbshopstor" <?php echo $user['webbshopstor'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Uppsägning Noll</th>
                <td><input type="checkbox" name="uppsagningnoll" <?php echo $user['uppsagningnoll'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Uppsägning Sex</th>
                <td><input type="checkbox" name="uppsagningsex" <?php echo $user['uppsagningsex'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Uppsägning Tolv</th>
                <td><input type="checkbox" name="uppsagningtolv" <?php echo $user['uppsagningtolv'] ? 'checked' : ''; ?>></td>
            </tr>
            <tr>
                <th>Total Price</th>
                <td><?php echo htmlspecialchars($user['price']); ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td>
                    <select name="status" class="select-status">
                        <option value="1" <?php echo $user['status'] == 1 ? 'selected' : ''; ?>>Inväntar förfrågan</option>
                        <option value="2" <?php echo $user['status'] == 2 ? 'selected' : ''; ?>>Granska</option>
                        <option value="3" <?php echo $user['status'] == 3 ? 'selected' : ''; ?>>Godkänd</option>
                        <option value="4" <?php echo $user['status'] == 4 ? 'selected' : ''; ?>>Påbörjat bygga</option>
                        <option value="5" <?php echo $user['status'] == 5 ? 'selected' : ''; ?>>Snart klar</option>
                        <option value="6" <?php echo $user['status'] == 6 ? 'selected' : ''; ?>>Klar</option>
                        <option value="7" <?php echo $user['status'] == 7 ? 'selected' : ''; ?>>Ombyggnation</option>
                        <option value="8" <?php echo $user['status'] == 8 ? 'selected' : ''; ?>>Ej godkänd</option>
                    </select>
                </td>
            </tr>

            <tr>
                <th>Meddelande</th>
                <td><?php echo htmlspecialchars($user['message']); ?></td>
            </tr>

            <tr>
                <th>reflink</th>
                <td><?php echo htmlspecialchars($user['reflink1']); ?></td>
            </tr>

            
        </table>
        <input type="submit" value="Update User">
    </form>

    <a href="admin.php" class="edit-button">Back to Admin</a>
</body>
</html>