<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    header("Location: login.php");
    exit();
}

// Fetch non-admin users along with their status and hemsida
$sql = "SELECT id, firstname, lastname, email, status, hemsida FROM users WHERE admin = 0";
$result = $conn->query($sql);

// Create an array to hold users organized by their status
$usersByStatus = [];
while ($user = $result->fetch_assoc()) {
    $usersByStatus[$user['status']][] = $user; // Group users by their status
}

// Define CSS colors for each status (optional)
$statusColors = [
    1 => '#dd9999', // Light red for status 1
    2 => '#ff9999', // Light red for status 1
    3 => '#99ff99', // Light green for status 2
    4 => '#9999ff', // Light blue for status 3
    5 => '#ffff99', // Light yellow for status 4
    6 => '#ffcc99', // Light orange for status 5
    7 => '#cccccc', // Gray for status 6
    8 => '#ffcccc', // Light pink for status 7
];

// Status descriptions
$statusDescriptions = [
    1 => 'Inväntar förfrågan',
    2 => 'Granskas',
    3 => 'Godkända',
    4 => 'Påbörjat bygga',
    5 => 'Snart klar',
    6 => 'Klar',
    7 => 'Ombyggnation',
    8 => 'Ej godkänd',
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .edit-button {
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            text-decoration: none;
        }
        .logout {
            margin-top: 20px;
            display: inline-block;
            text-decoration: none;
            background-color: #ff3b3b;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .status-section {
            margin-bottom: 40px; /* Space between sections */
            padding: 10px;
        }
        .status-explanation {
            margin-bottom: 20px;
            border: 1px solid #dddddd;
            padding: 15px;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <h2>Hej <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>

    <h3>Status typer</h3>
    
    <div class="status-explanation">
        <h4>Förklaringar:</h4>
        <ul>
            <?php foreach ($statusDescriptions as $key => $description): ?>
                <li><strong><?php echo htmlspecialchars($key); ?></strong> - <?php echo htmlspecialchars($description); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <?php foreach ($usersByStatus as $status => $users): ?>
        <div class="status-section" style="background-color: <?php echo $statusColors[$status] ?? '#f9f9f9'; ?>">
            <h4>Status <?php echo htmlspecialchars($status); ?>:</h4>
            <table>
                <thead>
                    <tr>
                        <th>Användar Id</th>
                        <th>Namn</th>
                        <th>Epost</th>
                        <th>Webbplats (hemsida)</th>
                        <th>Hantera</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['id']); ?></td>
                        <td><?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['hemsida']); ?></td>
                        <td>
                            <a class="edit-button" href="user.php?userID=<?php echo htmlspecialchars($user['id']); ?>">Hantera</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endforeach; ?>

    <a class="logout" href="logout.php">Logga ut</a>
    <a href="register.php" style="padding: 10px; background-color: #007bff; color: white; border-radius: 5px; text-decoration: none;">Registrera ny användare</a>
</body>
</html>