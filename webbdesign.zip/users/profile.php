<?php
session_start();
require 'db_connect.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch user information
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit();
}

// Handle form submissions for any button clicks
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['activate_subscription'])) {
        $stmt = $conn->prepare("UPDATE users SET abonnemang = 1, price = price + 299, status = 20 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit(); // added exit() to prevent further execution
    }

    if (isset($_POST['activate_fixed_price'])) {
        $stmt = $conn->prepare("UPDATE users SET fixed_price = 1, price = price + 3950 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_mall'])) {
        $stmt = $conn->prepare("UPDATE users SET mall = 1, price = price + 299, status = 21 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_unikdesign'])) {
        $stmt = $conn->prepare("UPDATE users SET unikdesign = 1, price = price + 299, status = 22 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_simpel'])) {
        $stmt = $conn->prepare("UPDATE users SET simpel = 1, price = price + 299, status = 22 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_stilren'])) {
        $stmt = $conn->prepare("UPDATE users SET stilren = 1, price = price + 299, status = 22 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_modern'])) {
        $stmt = $conn->prepare("UPDATE users SET modern = 1, price = price + 299, status = 22 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_undersidor1'])) {
        $stmt = $conn->prepare("UPDATE users SET undersidorliten = 1, price = price + 299, status = 23 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_undersidor2'])) {
        $stmt = $conn->prepare("UPDATE users SET undersidormellan = 1, price = price + 299, status = 23 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_undersidor3'])) {
        $stmt = $conn->prepare("UPDATE users SET undersidorstor = 1, price = price + 299, status = 23 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }



    if (isset($_POST['activate_animationernej'])) {
        $stmt = $conn->prepare("UPDATE users SET animationer = 0, price = price + 299, status = 24 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_animationerja'])) {
        $stmt = $conn->prepare("UPDATE users SET animationer = 1, price = price + 299, status = 24 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }


    if (isset($_POST['activate_seobasis'])) {
        $stmt = $conn->prepare("UPDATE users SET seobasis = 1, price = price + 299, status = 25 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_seoplus'])) {
        $stmt = $conn->prepare("UPDATE users SET seoplus = 1, price = price + 299, status = 25 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_seopremium'])) {
        $stmt = $conn->prepare("UPDATE users SET seopremium = 1, price = price + 299, status = 25 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }


    if (isset($_POST['activate_dashboardingen'])) {
        $stmt = $conn->prepare("UPDATE users SET dashboardingen = 1, price = price + 299, status = 26 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_dashboardenkel'])) {
        $stmt = $conn->prepare("UPDATE users SET dashboardlenkel = 1, price = price + 299, status = 26 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_dashboardavancerad'])) {
        $stmt = $conn->prepare("UPDATE users SET dashboardavancerad = 1, price = price + 299, status = 26 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }


    if (isset($_POST['activate_webbshopingen'])) {
        $stmt = $conn->prepare("UPDATE users SET webbshopingen = 1, price = price + 299, status = 27 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_webbshopliten'])) {
        $stmt = $conn->prepare("UPDATE users SET webbshopliten = 1, price = price + 299, status = 27 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_webbshopstor'])) {
        $stmt = $conn->prepare("UPDATE users SET webbshopstor = 1, price = price + 299, status = 27 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }


    
    if (isset($_POST['activate_uppsagning0'])) {
        $stmt = $conn->prepare("UPDATE users SET uppsagningnoll = 1, price = price + 299, status = 28 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_uppsagning6'])) {
        $stmt = $conn->prepare("UPDATE users SET uppsagningsex = 1, price = price + 299, status = 28 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }
    if (isset($_POST['activate_uppsagning12'])) {
        $stmt = $conn->prepare("UPDATE users SET uppsagningtolv = 1, price = price + 299, status = 28 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }


    if (isset($_POST['activate_desciption'])) {
        // Sanitize and validate user ID (VERY IMPORTANT!)
        $user_id = (int)$_SESSION['user_id']; // Assuming user_id is stored in session. Adapt as needed.
    
        // Get and sanitize the user's message
        $user_message = isset($_POST['user_message']) ? trim($_POST['user_message']) : '';
    
        // Validate the message (e.g., check length)
        if (strlen($user_message) > 0 && strlen($user_message) <= 255) { // Example: Message must be between 1 and 255 characters
            // Prepare and execute the SQL query
            $stmt = $conn->prepare("UPDATE users SET status = 29, message = ? WHERE id = ?");
            $stmt->bind_param('si', $user_message, $user_id); // 's' for string (message), 'i' for integer (user_id)
    
            if ($stmt->execute()) {
                // Success!
                header('Location: profile.php#tjanstAnchorVal');
                exit();
            } else {
                // Error!
                error_log("Database error: " . $stmt->error);
                echo "An error occurred while updating your request. Please try again later.";
            }
        } else {
            // Invalid message
            echo "Please enter a message between 1 and 255 characters.";
        }
    }


if (isset($_POST['activate_ref'])) {
    // Sanitize and validate user ID (VERY IMPORTANT!)
    $user_id = (int)$_SESSION['user_id']; // Assuming user_id is stored in session. Adapt as needed.

    // Get and sanitize the user's URL
    $user_ref1 = isset($_POST['user_ref1']) ? trim($_POST['user_ref1']) : '';

    // Validate the URL
    if (filter_var($user_ref1, FILTER_VALIDATE_URL) !== false) {
        // URL is valid

        // Prepare and execute the SQL query
        $stmt = $conn->prepare("UPDATE users SET status = 30, reflink1 = ? WHERE id = ?");
        $stmt->bind_param('si', $user_ref1, $user_id); // 's' for string (URL), 'i' for integer (user_id)

        if ($stmt->execute()) {
            // Success!
            header('Location: profile.php#tjanstAnchorVal');
            exit();
        } else {
            // Error!
            error_log("Database error: " . $stmt->error);
            echo "An error occurred while updating your request. Please try again later.";
        }
    } else {
        // Invalid URL
        echo "Please enter a valid URL.";
    }
}


if (isset($_POST['activate_sendrequest'])) {
    $stmt = $conn->prepare("UPDATE users SET status = 2 WHERE id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    header('Location: profile.php');
    exit();
}





    //RESET EVERYTHING
    
    if (isset($_POST['gobacktest'])) {
        $stmt = $conn->prepare("UPDATE users SET 
            abonnemang = 0, 
            fastpris = 0, 
            mall = 0, 
            simpel = 0, 
            stilren = 0, 
            modern = 0, 
            unikdesign = 0, 
            undersidorliten = 0, 
            undersidormellan = 0, 
            undersidorstor = 0, 
            animationer = 0, 
            seobasis = 0, 
            seoplus = 0, 
            seopremium = 0, 
            dashboardingen = 0, 
            dashboardlenkel = 0, 
            dashboardavancerad = 0, 
            webbshopingen = 0, 
            webbshopliten = 0, 
            webbshopstor = 0, 
            uppsagningnoll = 0, 
            uppsagningsex = 0, 
            uppsagningtolv = 0,
            status = 1,
            price = 0
            WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        header('Location: profile.php#tjanstAnchorVal');
        exit();
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- CSS Links -->
    <link rel="preload" href="root/css/profile.css" as="style">
    <link rel="stylesheet" href="../root/css/profile.css">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style" onload="this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    </noscript>
    

      <!-- Preconnect for Google Fonts -->
      <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
        <!-- Google Fonts Preload -->
        <link id="google-fonts" rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bevan&family=Merriweather:wght@400;700&family=Open+Sans:wght@400;600;700&display=swap" media="print" onload="this.media='all'">
        <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bevan&family=Merriweather:wght@400;700&family=Open+Sans:wght@400;600;700&display=swap"></noscript>

</head>
<body>

<div class="topcontainer">

    <div class="topcontainer-content">

        <div class="topcontainer-content-left">
            <h2>Hej, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
        </div>

        <div class="topcontainer-content-right">

            <div class="topcontainer-content-right-item">
            <?php
                if ($user['hemsida']) { // Check if hemsida is truthy (not null, not empty)
                    ?>
                    <a href="<?php echo htmlspecialchars($user['hemsida']); ?>" target="_blank" rel="noopener noreferrer">
                        <i class="fa-solid fa-globe"></i>
                        <p>Din hemsida</p>
                    </a>
                    <?php
                } else { // If hemsida is null or empty, don't display the link
                    ?>
                    <i class="fa-solid fa-globe"></i>
                    <p>Din hemsida</p>
                    <?php
                }
                ?>
            </div>
            
            <div class="topcontainer-content-right-item">
                <a>
                    <i class="fa-solid fa-tools"></i> <!-- Icon for "Dina tjänster" -->
                    <p>Dina tjänster</p>
                </a>
            </div>
            
            <div class="topcontainer-content-right-item">
                <a>
                    <i class="fa-solid fa-pencil-alt"></i> <!-- Icon for "Redigera innehåll" -->
                    <p>Redigera innehåll</p>
                </a>
            </div>
            
            <div class="topcontainer-content-right-item">
                <a>
                    <i class="fa-solid fa-comments"></i> <!-- Icon for "Meddelande" -->
                    <p>Meddelande</p>
                </a>
            </div>
            
            <div class="topcontainer-content-right-item">
                <a href="logout.php">
                    <i class="fa-solid fa-right-from-bracket"></i> <!-- Icon for "Logga ut" -->
                    <p>Logga ut</p>
                </a>
            </div>

            </div>

        </div>

    </div>
</div>

<div class="valkommencontainer">

    <div class="valkommencontainer-content">

        <div class="valkommencontainer-content-left">
            <h2>Ta kontroll över <span>din hemsida</span></h2>
            <p>Välkommen till din Weebey Portal. Här kan du hitta allt du behöver för att se din status på din hemsida
                du kan även göra mindre ändringar på sidan, uppgradera dina tjänster, se fakturor och mycket mer.
            </p>

            <button class="mainButton">Dina tjänster</button>

        </div>

        <div class="valkommencontainer-content-right">
            <div class="valkommencontainer-content-right-pris">
            <p>

            <?php switch ($user['status']) {
    case in_array($user['status'], array(1, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30)) ? $user['status'] : null:
        echo "Nuvarande status";
        break;
            case 2:
                echo "Nuvarande status";
                break;
            case 3:
                echo "Nuvarande status";
                break;
            case 4:
                echo "Nuvarande status";
                break;
            case 5:
                echo "Nuvarande status";
                break;
            case 7:
                echo "Nuvarande status";
                break;
            case 8:
                echo "Nuvarande status";
                break;
            default:
                echo "Du betalar just nu";
                break;
        } ?>
    </p>
    <h2>
    <?php switch ($user['status']) {
    case in_array($user['status'], array(1, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30)) ? $user['status'] : null:
        echo "1";
        break;
            case 2:
                echo "2";
                break;
            case 3:
                echo "3";
                break;
            case 4:
                echo "4";
                break;
            case 5:
                echo "5";
                break;
            case 7:
                echo "B";
                break;
            case 8:
                echo "0";
                break;
            default:
                echo htmlspecialchars($user['price']);
                break;
        } ?>
    </h2>
    <p>
    <?php switch ($user['status']) {
    case in_array($user['status'], array(1, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30)) ? $user['status'] : null:
        echo "Inväntar förfrågan";
        break;
            case 2:
                echo "Granskning";
                break;
            case 3:
                echo "Hemsidan godkänd";
                break;
            case 4:
                echo "Byggnation pågår";
                break;
            case 5:
                echo "Hemsidan är snart klar";
                break;
            case 7:
                echo "Ombyggnation pågår";
                break;
            case 8:
                echo "Ej godkänd";
                break;
            default:
                echo "kronor varje månad";
                break;
        } ?>
            </p>

        </div>
        </div>

    </div>

</div>

<div class="status-container">
    <h3>Status för din hemsida</h3>
    

<?php
switch ($user['status']) {
    case in_array($user['status'], array(1, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30)) ? $user['status'] : null:
        echo '        <div class="status-item">
        <p>
        Inväntar förfrågan
        </p>
    <div class="status-item-1"></div>
    
    </div>
    <p id="statusP2">Vi inväntar din förfrågan, nedanför kan ni välja era tjänster och förklara era önskemål så mycket som möjligt.</p>
    <button class="mainButton">Välj tjänster</button>';
        break;

            case 2:
                echo '        <div class="status-item">
        <p>
        Din förfrågan granskas
        </p>
    <div class="status-item-2"></div>
    
    </div>
    <p id="statusP2">Just nu håller vi på att granska din ansökan om eran hemsida. Vi kommer snart att återkomma med ett svar på eran begäran och en slutligt pris.</p>
    <button class="mainButton">Dina meddelanden</button>';
                break;


            case 3:
                echo '        <div class="status-item">
        <p>
        Din förfrågan är godkänd
        </p>
    <div class="status-item-3"></div>
    
    </div>
    <p id="statusP2">Vi har godkänt er förfrågan angående hemsidan. Vi ha skickat ett meddelande till er med mer information och prisuppgifter.</p>
    <button class="mainButton">Dina meddelanden</button>';
                break;
            case 4:
                echo '     <div class="status-item">
        <p>
        Hemsidan är under uppbyggnad
        </p>
    <div class="status-item-4"></div>
    
    </div>
    <p id="statusP2">Vi håller just nu på att bygga eran hemsida. Håll utkik i era meddelande vid eventuella frågor från våra webbdesigners.</p>
    <button class="mainButton">Dina meddelanden</button>';
                
    break;
            case 5:
                echo '     <div class="status-item">
        <p>
        Hemsidan är snart klar
        </p>
    <div class="status-item-5"></div>
    
    </div>
    <p id="statusP2">Eran hemsida är inte långt ifrån klar nu. Vi håller just nu på att fixa de sista detaljerna och utför användartester för att säkerställa att allt fungerar som det ska.</p>
    <button class="mainButton">Dina meddelanden</button>';
                break;
            case 6:
                echo '     <div class="status-item">
        <p>
        Hemsidan är publicerad
        </p>
    <div class="status-item-6"></div>
    
    </div>
    <p id="statusP2">Grattis, eran hemsida är publicerad!</p>
        <button class="mainButton">Se din hemsida</button>';
                break;

                case 7:
                    echo '     <div class="status-item">
            <p id="statusMain6">
            Ombyggnation pågår
            </p>
        <div class="status-item-6"></div>
        
        </div>
        <p id="statusP2">Vi håller på att bygga om vissa delar av eran hemsida. Håll utkik bland era meddelande vid eventuella frågor från våra webbdesigners.</p>
        <button class="mainButton">Dina meddelanden</button>';
                    break;

                    case 8:
                        echo '     <div class="status-item">
                <p id="statusMain7">
                Inte godkänd
                </p>
            <div class="status-item-7"></div>
            
            </div>
            <p id="statusP2">Tyvärr kunde vi inte godkänna eran begäran om eran hemsida, det kan beror på många faktorer. Vi ber er att titta på era meddelande för mer information.</p>
            <button class="mainButton">Dina meddelanden</button>';
                        break;

            default:
                echo '<div>Status not set</div>';
                break;
        }
        ?>
        
        
        
    



    <svg id="svgPathProfile" xmlns="http://www.w3.org/2000/svg" viewBox="0 -100 1000 100" fill="#F7F5F2">
        <path d="M0 0v-90.2C49.7 -99.9 105 -82 160 -65c75.5 23.3 145.5 22.4 222 3 63 -16 119 -14 173 8 79.5 32.4 156.2 27.6 240 10 82.6 -17.4 143 1 205 31.7V0H0Z"></path>
    </svg>
</div>




<?php if ($user['status'] == 1 || $user['status'] == 20 || $user['status'] == 21 || $user['status'] == 22 || $user['status'] == 23 || $user['status'] == 24 || $user['status'] == 25 || $user['status'] == 26 || $user['status'] == 27 || $user['status'] == 28 || $user['status'] == 29 || $user['status'] == 30): ?>

    <div class="currentpricecontainer">
<h2 id="tjanstAnchorVal"><span><?php echo htmlspecialchars($user['price']); ?></span><br>kr / månaden</h2>

    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="gobacktest">börja om</button> 
    </form>
</div>

<?php endif; ?>

    <!--ANVÄNDARAEN KOMMER TILL SIDAN FÖRSAT GÅNGEN-->

    <?php if ($user['status'] == 1): ?>

    <div class="aktivatjanster-container">
            <div class="noselect">

            <h2>Hur vill du betala?</h2>
            <p>Välj hur du föredrar att betala för din hemsida</p>

        <div class="noselect-container">
            <div class="noselect-item">
                <h2>Abonnemang</h2>
                <p>Ett abonnemang hos oss kostar från 399 kr i månaden och då ingår det obegränsat underhåll
                    och fria uppdateringar. Man kan även välja att ha möjlighet att säga upp abonnemanget när man vill
                </p>
            </div>
            <div class="noselect-item">
                <h2>Fast pris</h2>
                <p>Ett abonnemang hos oss kostar från 399 kr i månaden och då ingår det obegränsat underhåll
                    och fria uppdateringar. Man kan även välja att ha möjlighet att säga upp abonnemanget när man vill
                </p>
            </div>
        </div>
        
        <form method="POST" action="">
            <button class="mainButton noselectbtn" type="submit" name="activate_subscription">Välj bonnemang</button>
            <button class="mainButton noselectbtn" type="submit" name="activate_fixed_price">Välj fast pris</button>
        </form>

    </div>
</div>
<?php endif; ?>


    <!--ANVÄNDARAEN HAR VALT ABONNEMANG OCH SKA NU VÄLJA STEG 2-->

    <?php if ($user['status'] == 20): ?>

<div class="aktivatjanster-container">
        <div class="noselect">

        <h2>Design val</h2>
        <p>Vilken design vill du ha på din hemsida?</p>

    <div class="noselect-container">
        <div class="noselect-item">
            <h2>Färdig mall</h2>
            <p>En färdig mall är lite kostar inget extra, du kommer få välja mellan 3 olika stilar.
            </p>
        </div>
        <div class="noselect-item">
            <h2>Unik design</h2>
            <p>Vi skräddarsyr en unik design. Din hemsida kommer se ut precis som du vill och inte se ut som någon annan hemsida.
            </p>
        </div>
    </div>
    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="activate_mall">Välj en mall</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_unikdesign">Välj Unik design</button>
    </form>
</div>
</div>
<?php endif; ?>


    <!--ANVÄNDARAEN HAR VALT ABONNEMANG OCH MALL-->

    <?php if ($user['status'] == 21): ?>

<div class="aktivatjanster-container">
        <div class="noselect">

        <h2>Val av mall</h2>
        <p>Vilken typ av mall vill du ha?</p>

    <div class="noselect-container">
        <div class="noselect-item">
            <h2>Simpel</h2>
            <p>En simpel mall
            </p>
        </div>
        <div class="noselect-item">
            <h2>Stilren</h2>
            <p>En Stilren mall
            </p>
        </div>
        <div class="noselect-item">
            <h2>Modern</h2>
            <p>En Modern mall
            </p>
        </div>
    </div>
    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="activate_simpel">Välj simpel</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_stilren">Välj stilren</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_modern">Välj modern</button>
        
    </form>
</div>
</div>
<?php endif; ?>


    <!--ANVÄNDARAEN HAR VALT ABONNEMANG OCH UNIK DESIGN-->

    <?php if ($user['status'] == 22): ?>

<div class="aktivatjanster-container">
        <div class="noselect">

        <h2>Undersidor</h2>
        <p>Hur många undersidor behöver du ha på hemsidan?</p>

    <div class="noselect-container">
        <div class="noselect-item">
            <h2>1-3 undersidor</h2>
            <p>Jag behöver ha 1-3 undersidor på min hemsida.FAWFWAF
            </p>
        </div>
        <div class="noselect-item">
            <h2>4-6 undersidor</h2>
            <p>Jag behöver ha 4-6 undersidor på min hemsida.
            </p>
        </div>
        <div class="noselect-item">
            <h2>7+ undersidor</h2>
            <p>Jag behöver ha 7 eller fler undersidor på min hemsida.
            </p>
        </div>
    </div>
    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="activate_undersidor1">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_undersidor2">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_undersidor3">Välj tjänst</button>
        
    </form>
</div>
</div>
<?php endif; ?>


<!--ANVÄNDARAEN HAR VALT UNDERSIDOR-->

<?php if ($user['status'] == 23): ?>

<div class="aktivatjanster-container">
        <div class="noselect">

        <h2>Animatoner</h2>
        <p>Vill ni ha animationer på hemsidan.</p>

    <div class="noselect-container">
        <div class="noselect-item">
            <h2>JA</h2>
            <p>Jag vill inte ha några animationer
            </p>
        </div>
        <div class="noselect-item">
            <h2>NEJ</h2>
            <p>Jag vill ha animationer
            </p>
        </div>
    </div>
    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="activate_animationernej">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_animationerja">Välj tjänst</button>
        
    </form>
</div>
</div>
<?php endif; ?>


<?php if ($user['status'] == 24): ?>

<div class="aktivatjanster-container">
        <div class="noselect">

        <h2>SEO</h2>
        <p>Vilken typ av Sökoptimering vill du ha på hemsidan?</p>

    <div class="noselect-container">
        <div class="noselect-item">
            <h2>Basis</h2>
            <p>Jag vill inte ha några animationer
            </p>
        </div>
        <div class="noselect-item">
            <h2>PLUS</h2>
            <p>Jag vill ha animationer
            </p>
        </div>
        <div class="noselect-item">
            <h2>PREMIUM</h2>
            <p>Jag vill ha animationer
            </p>
        </div>
    </div>
    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="activate_seobasis">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_seoplus">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_seopremium">Välj tjänst</button>
        
    </form>
</div>
</div>
<?php endif; ?>



<?php if ($user['status'] == 25): ?>

<div class="aktivatjanster-container">
        <div class="noselect">

        <h2>Dashboard</h2>
        <p>Vilken typ av dashboard vill du ha på hemsidan?</p>

    <div class="noselect-container">
        <div class="noselect-item">
            <h2>Ingen</h2>
            <p>Jag vill inte ha nån
            </p>
        </div>
        <div class="noselect-item">
            <h2>En enkel</h2>
            <p>Jag vill ha en enkel
            </p>
        </div>
        <div class="noselect-item">
            <h2>En avancerad</h2>
            <p>Jag vill ha en avancerad
            </p>
        </div>
    </div>
    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="activate_dashboardingen">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_dashboardenkel">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_dashboardavancerad">Välj tjänst</button>
        
    </form>
</div>
</div>
<?php endif; ?>


<?php if ($user['status'] == 26): ?>

<div class="aktivatjanster-container">
        <div class="noselect">

        <h2>Webbshop</h2>
        <p>Behöver du sälja produter på din hemsida??</p>

    <div class="noselect-container">
        <div class="noselect-item">
            <h2>Nej</h2>
            <p>Jag vill inte ha nån
            </p>
        </div>
        <div class="noselect-item">
            <h2>Ja</h2>
            <p>Jag vill ha en enkel
            </p>
        </div>
        <div class="noselect-item">
            <h2>Ja, massor</h2>
            <p>Jag vill ha en avancerad
            </p>
        </div>
    </div>
    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="activate_webbshopingen">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_webbshopliten">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_webbshopstor">Välj tjänst</button>
        
    </form>
</div>
</div>
<?php endif; ?>


<?php if ($user['status'] == 27 && $user['abonnemang']): ?>

<div class="aktivatjanster-container">
        <div class="noselect">

        <h2>Uppsägningstid</h2>
        <p>Hur lång Uppsägningstid vill du ha?</p>

    <div class="noselect-container">
        <div class="noselect-item">
            <h2>0 månader</h2>
            <p>Jag vill inte ha nån Uppsägningstid
            </p>
        </div>
        <div class="noselect-item">
            <h2>Ja</h2>
            <p>Jag vill ha 6 månader Uppsägningstid
            </p>
        </div>
        <div class="noselect-item">
            <h2>Ja, massor</h2>
            <p>Jag vill ha 12 månader Uppsägningstid
            </p>
        </div>
    </div>
    
    <form method="POST" action="">
        <button class="mainButton noselectbtn" type="submit" name="activate_uppsagning0">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_uppsagning6">Välj tjänst</button>
        <button class="mainButton noselectbtn" type="submit" name="activate_uppsagning12">Välj tjänst</button>
        
    </form>
</div>
</div>
<?php endif; ?>



<?php if ($user['status'] == 28): ?>
    <div class="aktivatjanster-container">
        <div class="noselect">
            <h2>Om din sida</h2>
            <p>Berätta om din hemsida</p>
            <div class="noselect-container">
                
            <form action="" method="post">
        <label for="user_message">Your Message:</label><br>
        <textarea id="user_message" name="user_message" rows="4" cols="50" placeholder="Please enter your message here"></textarea><br><br>
        <button type="submit" name="activate_desciption">Submit Description</button>
    </form>
            </div>
        </div>
    </div>
<?php endif; ?>



<?php if ($user['status'] == 29 && $user['unikdesign']): ?>
    <div class="aktivatjanster-container">
        <div class="noselect">
            <h2>Insperations sidor</h2>
            <p>Sidor som ni tycker ha en bra design</p>
            <div class="noselect-container">

            <form action="" method="post">
        <label for="user_ref1">Your URL:</label><br>
        <input type="url" id="user_ref1" name="user_ref1" placeholder="Please enter your URL (e.g., https://www.brillianik.se)"><br><br>

        <button type="submit" name="activate_ref">Submit URL</button>
    </form>
            </div>
        </div>
    </div>
<?php endif; ?>





<?php if ($user['status'] == 30 || $user['status'] == 29 && $user['mall']): ?>
    <div class="aktivatjanster-container">
        <div class="noselect">
            <h2>DINA VAL</h2>
            <h2 id="tjanstAnchorVal">Pris per månad: <?php echo htmlspecialchars($user['price']); ?>!</h2>
            <p>Detta är allt du valt</p>

            
            <div class="noselect-container noselect-containerlist">


            <?php if ($user['abonnemang']): ?>
            <div class="selected-item">
            <h3>Abonnemang<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['fastpris']): ?>
            <div class="selected-item">
            <h3>Fastpris<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['mall'] && $user['simpel']): ?>
            <div class="selected-item">
            <h3>Mall - Simpel<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['mall'] && $user['stilren']): ?>
            <div class="selected-item">
            <h3>Mall - Stilren<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['mall'] && $user['modern']): ?>
            <div class="selected-item">
            <h3>Mall - Modern<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>


            <?php if ($user['unikdesign']): ?>
            <div class="selected-item">
            <h3>Unik design<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>



            <?php if ($user['undersidorliten']): ?>
            <div class="selected-item">
            <h3>Undersidor 1-3:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['undersidormellan']): ?>
            <div class="selected-item">
            <h3>Undersidor 4-6:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['undersidorstor']): ?>
            <div class="selected-item">
            <h3>Undersidor +7:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['animationer']): ?>
            <div class="selected-item">
            <h3>Animationer:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['seobasis']): ?>
            <div class="selected-item">
            <h3>SEO Basis:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['seoplus']): ?>
            <div class="selected-item">
            <h3>SEO Plus:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['seopremium']): ?>
            <div class="selected-item">
            <h3>SEO Premium:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['dashboardingen']): ?>
            <div class="selected-item">
            <h3>Dashboard:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['dashboardlenkel']): ?>
            <div class="selected-item">
            <h3>Enkel Dashboard:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['dashboardavancerad']): ?>
            <div class="selected-item">
            <h3>Avancerad Dashboard:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['webbshopingen']): ?>
            <div class="selected-item">
            <h3>Webbshop:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['webbshopliten']): ?>
            <div class="selected-item">
            <h3>Webbshop Liten:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['webbshopstor']): ?>
            <div class="selected-item">
            <h3>Webbshop Stor:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['uppsagningnoll']): ?>
            <div class="selected-item">
            <h3>Uppsägningstid 0:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['uppsagningsex']): ?>
            <div class="selected-item">
            <h3>Uppsägningstid 6:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>

            <?php if ($user['uppsagningtolv']): ?>
            <h3>Uppsägningstid 12:<h3>
            <div>
                <p>Du har valt att betala med ett abonnemang. Kommer kosta PRICE i månaden.</p>
            </div>
            </div>
            <?php endif; ?>


        <form method="POST" action="">
            <button class="mainButton noselectbtn" type="submit" name="activate_sendrequest">Skicka förfrågan</button>
        </form>
            </div>
        </div>
    </div>
<?php endif; ?>
















<?php if ($user['status'] == 2): ?>
    <div class="aktivatjanster-container">
        

        <div class="aktivatjanster">

        
            <div id="tjanstmoveleft">
            <i class="fa-solid fa-angle-left" aria-hidden="true"></i>
            </div>

            <div id="tjanstmoveright">
            <i class="fa-solid fa-angle-right" aria-hidden="true"></i>
            </div>
        
        
            <?php if($user['abonnemang']): ?>
                <div class="tjanstitem" id="abonnemang">
                    <div class="tjanstitemTop">
                        <div class="tjanstitemTop-icon">
                            <i class="fa-solid fa-box"></i>
                        </div>
                    </div>

                    <div class="tjanstitemmiddle">
                        <h2>Betalningsalternativ</h2>
                        <h3>Abonnemang</h3>
                        <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                    </div>
                    <div class="tjanstitembottom">
                        <button class="mainButton">Ändra</button>
                    </div>
                </div>

            <?php endif; ?>
            
            <?php if($user['fastpris']): ?>
            <div class="tjanstitem" id="fastpris">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Betalningsalternativ</h2>
                    <h3>Fast pris</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['mall']): ?>
            <div class="tjanstitem" id="mall">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Design val</h2>
                    <h3>Färdig mall</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['simpel']): ?>
            <div class="tjanstitem" id="simpel">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Design val</h2>
                    <h3>Simpel design</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['stilren']): ?>
            <div class="tjanstitem" id="stilren">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Design val</h2>
                    <h3>Stilren design</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>






            
            <?php if($user['modern']): ?>
            <div class="tjanstitem" id="modern">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Design val</h2>
                    <h3>Modern design</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['unikdesign']): ?>
            <div class="tjanstitem" id="unikdesign">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Design val</h2>
                    <h3>Unik design</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['undersidorliten']): ?>
            <div class="tjanstitem" id="undersidor1">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Undersidor</h2>
                    <h3>1-3 undersidor</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['undersidormellan']): ?>
            <div class="tjanstitem" id="undersidor2">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Undersidor</h2>
                    <h3>4-6 undersidor</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['undersidorstor']): ?>
            <div class="tjanstitem" id="undersidor3">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Undersidor</h2>
                    <h3>7+ undersidor</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['animationer']): ?>
            <div class="tjanstitem" id="animationer">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Animationer</h2>
                    <h3>Används</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['seobasis']): ?>
            <div class="tjanstitem" id="seobasis">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Sökoptimering</h2>
                    <h3>Basis</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['seoplus']): ?>
            <div class="tjanstitem" id="seoplus">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Sökoptimering</h2>
                    <h3>Plus</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['seopremium']): ?>
            <div class="tjanstitem" id="seopremium">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Sökoptimering</h2>
                    <h3>Premium</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['dashboardingen']): ?>
            <div class="tjanstitem" id="dashboard">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Dashboard</h2>
                    <h3>Ej tillgänlig</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Lägg till</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['dashboardlenkel']): ?>
            <div class="tjanstitem" id="dashboardlenkel">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Dashboard</h2>
                    <h3>Enkel</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['dashboardavancerad']): ?>
            <div class="tjanstitem" id="dashboardavancerad">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Dashboard</h2>
                    <h3>Avancerad</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['webbshopingen']): ?>
            <div class="tjanstitem" id="webbshopingen">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Webbshop</h2>
                    <h3>Ej tillgänlig</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['webbshopliten']): ?>
            <div class="tjanstitem" id="webbshopliten">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Webbshop</h2>
                    <h3>Liten</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['webbshopstor']): ?>
            <div class="tjanstitem" id="webbshopstor">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Webbshop</h2>
                    <h3>Stor</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['uppsagningnoll']): ?>
            <div class="tjanstitem" id="uppsagningnoll">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Uppsägningstid</h2>
                    <h3>0 månader</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['uppsagningsex']): ?>
            <div class="tjanstitem" id="uppsagningsex">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Uppsägningstid</h2>
                    <h3>6 månader</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if($user['uppsagningtolv']): ?>
            <div class="tjanstitem" id="uppsagningtolv">
                <div class="tjanstitemTop">
                    <div class="tjanstitemTop-icon">
                        <i class="fa-solid fa-paintbrush"></i>
                    </div>
                </div>

                <div class="tjanstitemmiddle">
                    <h2>Uppsägningstid</h2>
                    <h3>12 månader</h3>
                    <p>Du har ett abonnemangsavtal som ger dig tillgång till våra tjänster.</p>
                </div>
                <div class="tjanstitembottom">
                    <button class="mainButton">Ändra</button>
                </div>
            </div>
            <?php endif; ?>
        </div>

    </div>

    <?php endif; ?>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const tjansterContainer = document.querySelector('.aktivatjanster');
            const moveLeftBtn = document.getElementById('tjanstmoveleft');
            const moveRightBtn = document.getElementById('tjanstmoveright');
    
            moveRightBtn.addEventListener('click', function() {
                tjansterContainer.scrollBy({
                    top: 0,
                    left: 350, // Scroll 300px to the right
                    behavior: 'smooth' // Smooth scrolling
                });
            });
    
            moveLeftBtn.addEventListener('click', function() {
                tjansterContainer.scrollBy({
                    top: 0,
                    left: -350, // Scroll 300px to the left
                    behavior: 'smooth' // Smooth scrolling
                });
            });
        });
    </script>
    



    

</body>
</html>