
<?php
// login.php

session_start();
require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string(trim($_POST['username']));
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['firstname'] . ' ' . $user['lastname'];
            $_SESSION['is_admin'] = $user['admin']; // Use 'admin' according to your database structure

            // Redirect based on admin status
            if ($_SESSION['is_admin']) {
                header("Location: admin.php");
            } else {
                header("Location: profile.php");
            }
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with this email.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- CSS Links -->
    <link rel="preload" href="root/css/login.css" as="style">
    <link rel="stylesheet" href="../root/css/login.css">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style" onload="this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    </noscript>
    <link id="google-fonts" rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bevan&family=Merriweather:wght@400;700&family=Open+Sans:wght@400;600;700&display=swap" media="print" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bevan&family=Merriweather:wght@400;700&family=Open+Sans:wght@400;600;700&display=swap"></noscript>
</head>
<body>
<section class="loggin-container">
    <div class="loggin-content">
        <h2><span>Weebey</span> Portalen</h2>
        <p>För dig som är kund hos oss, logga in här för att se över din hemsida och få tillgång till dina egna sidor och tjänster.</p>
        <form method="POST" action="login.php">
            <div class="form-group">
                <input type="email" id="username" name="username" required placeholder="Ange din e-post">
            </div>
            <div class="form-group">
                <input type="password" id="password" name="password" required placeholder="Ange ditt lösenord">
            </div>
            <button type="submit" class="login-button mainButton">Logga in</button>
        </form>
        <div class="forgot-password">
            <a href="/forgot-password">Glömt ditt lösenord?</a><br>
        </div>
        <div class="forgot-password">
            <a href="register.php">Registrera</a>
        </div>
    </div>
</section>
</body>
</html>