<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the database connection file
require_once 'db_connect.php';

$registrationMessage = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form inputs and sanitize them
    $firstname = $conn->real_escape_string(trim($_POST['firstname']));
    $lastname = $conn->real_escape_string(trim($_POST['lastname']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $phone = $conn->real_escape_string(trim($_POST['phone']));
    $password = $_POST['password']; // Get the password

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert the user into the database
    $sql = "INSERT INTO users (firstname, lastname, email, phone, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("sssss", $firstname, $lastname, $email, $phone, $hashedPassword);
        
        if ($stmt->execute()) {
            // Redirect to the login page after successful registration
            header("Location: https://www.brillianik.se/users/login.php");
            exit(); // Make sure to call exit after redirection
        } else {
            $registrationMessage = "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $registrationMessage = "Error preparing statement: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <style>
        /* Add your styles here */
    </style>
</head>
<body>
    <div class="container">
        <form method="post" action="">

            <div class="form-item" id="form-item1">
                <h2>Dina uppgifter</h2>
                <label for="firstname">Förnamn</label>
                <input type="text" name="firstname" required>

                <label for="lastname">Efternamn</label>
                <input type="text" name="lastname" required>

                <label for="email">E-post:</label>
                <input type="email" name="email" required>

                <label for="phone">Telefon:</label>
                <input type="text" name="phone" required>

                <label for="password">Lösenord:</label>
                <input type="password" name="password" required>

            </div>

            <input type="submit" value="Register">
        </form>

        <?php if ($registrationMessage) : ?>
            <?php if ($registrationMessage == "Registration successful!") : ?>
                <div class="success"><?php echo $registrationMessage; ?></div>
            <?php else : ?>
                <div class="error"><?php echo $registrationMessage; ?></div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>