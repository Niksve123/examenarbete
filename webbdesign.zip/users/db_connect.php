<?php
$host = 'mysql1-1.hostek.se';
$user = 'udmybs471051';
$password = 'gom0S:0_kh.8PWjb';
$database = 'dbs127404';

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>