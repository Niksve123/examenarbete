// Import the required libraries
const Groq = require('groq-sdk');
const readline = require('readline');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

// Replace 'YOUR_API_KEY' with your actual Groq API key
const groq = new Groq({
  apiKey: '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', // replace with your actual API key
});

// Create an instance of Express
const app = express();
const PORT = process.env.PORT || 3000;

// Add middleware
app.use(cors());
app.use(bodyParser.json());

// Initialize the chat messages array
let messages = [];

// Define an endpoint to handle chat requests
app.post('/chat', async (req, res) => {
  const userInput = req.body.message;

  // Add user input to the messages array
  messages.push({ role: 'user', content: userInput });

  try {
    // Create a chat completion request
    const chatCompletion = await groq.chat.completions.create({
      "messages": messages,
      "model": "llama-3.3-70b-versatile",
      "temperature": 1,
      "max_completion_tokens": 1024,
      "top_p": 1,
      "stream": false,  // Set to false for direct response
      "stop": null
    });

    // Get assistant's response
    const assistantResponse = chatCompletion.choices[0].message.content;
    // Add assistant response to the messages array
    messages.push({ role: 'assistant', content: assistantResponse });

    // Send the response back to the client
    res.json({ response: assistantResponse });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'An error occurred while processing your request.' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});