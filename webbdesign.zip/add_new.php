<?php
// Include the database connection file
include 'db_connect.php';

// Initialize variables to hold error messages and success message
$errorMessage = '';
$successMessage = '';

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize input from the form
    $foretagsnamn = $conn->real_escape_string(trim($_POST['foretagsnamn']));

    // Prepare the SQL insert statement
    $sql = "INSERT INTO main (foretagsnamn) VALUES ('$foretagsnamn')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        $successMessage = "Företag added successfully!";
    } else {
        $errorMessage = "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Företag</title>
</head>
<body>
    <h1>Add New Företag</h1>

    <?php
    // Display success or error message
    if (!empty($successMessage)) {
        echo "<p style='color: green;'>$successMessage</p>";
    }
    if (!empty($errorMessage)) {
        echo "<p style='color: red;'>$errorMessage</p>";
    }
    ?>

    <form method="post" action="">
        <label for="foretagsnamn">Företagsnamn:</label>
        <input type="text" name="foretagsnamn" required>
        <br>

        <input type="submit" value="Add Företag">
    </form>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>