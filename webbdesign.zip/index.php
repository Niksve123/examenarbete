<?php
// Include the database connection
include 'db_connect.php'; // Ensure this file correctly establishes a database connection.

// Fetch företagsnamn from the "main" table
$foretags = [];
$sql = "SELECT foretagsnamn FROM main";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $foretags[] = $row['foretagsnamn'];
    }
} else {
    echo "0 results";
}

// Close the database connection if you want, this is optional.
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat with AI</title>
    <link rel="stylesheet" href="styles.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">

</head>
<body>


    <div class="loadingscreen">
        <div class="spinner">
        <svg class="loading-animation" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 150">
            <path fill="none" stroke="#4BA6E1" stroke-width="10" stroke-linecap="round" stroke-dasharray="300 385" stroke-dashoffset="0" d="M275 75c0 31-27 50-50 50-58 0-92-100-150-100-28 0-50 22-50 50s23 50 50 50c58 0 92-100 150-100 24 0 50 19 50 50Z">
                <animate attributeName="stroke-dashoffset" calcMode="spline" dur="2" values="685;-685" keySplines="0 0 1 1" repeatCount="indefinite"></animate>
            </path>
        </svg>
        <div class="loading-text"><span style="font-size: 1.4em; font-weight: bolder; letter-spacing: 0px;">NIKAI.</span><br>Generarer texten</div>
        <div class="loadingbar">
            <div class="loadingbar-loader"></div>
        </div>
        </div>
    </div>


<div class="mainBody">

<video autoplay muted loop class="background-video">
    <source src="assets/bg4.mp4" type="video/mp4">
    Your browser does not support the video tag.
</video>


<div id="chat">
    <div id="messages">
    </div>
    
    <div id="filterbox">
    <select id="kategori">
        <option value="">Välj Kategori</option>
        <option value="mobler">Möbler</option>
        <option value="klader">Kläder</option>
        <option value="cyklar">Cyklar</option>
        <option value="friskvard">Friskvård</option>
        <option value="restauranger">Restauranger</option>
        <option value="resor">Resor</option>
        <option value="teknik">Teknik</option>
        <option value="skonhet">Skönhet</option>
        <option value="utbildning">Utbildning</option>
        <option value="finans">Finans</option>
        <option value="underhallning">Underhållning</option>
        <option value="bilar">Bilar</option>
        <option value="fastigheter">Fastigheter</option>
        <option value="jewelry">Smycken</option>
        <option value="livsmedel">Livsmedel</option>
        <option value="konst">Konst</option>
        <option value="sport">Sport</option>
        <option value="musik">Musik</option>
        <option value="diy">DIY & Hemmafix</option>
        <option value="barnprodukter">Barnprodukter</option>
        <option value="hemelektronik">Hemelektronik</option>
        <option value="boker">Böcker</option>
        <option value="klimat">Klimat & Miljö</option>
        <option value="blommor">Blommor & Växter</option>
        <option value="hantverk">Hantverk & Design</option>
        <option value="presenter">Presenter</option>
        <option value="resprylar">Resprylar</option>
        <option value="kurser">Kurser</option>
    </select>

    <select id="subkategori">
        <option value="">Underkategori</option>
    </select>

    <select id="rubriker">
        <option value="">Antal sökord</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
    </select>
    
    <select id="sprak">
        <option value="">Välj Språk</option>
        <option value="svenska">Svenska</option>
        <option value="engelska">Engelska</option>
        <option value="tyska">Tyska</option>
        <option value="franska">Franska</option>
        <option value="spanska">Spanska</option>
    </select>

    <select id="foretags">
        <option value="">Välj Företag</option>
        <?php foreach ($foretags as $foretag): ?>
            <option value="<?= htmlspecialchars($foretag) ?>"><?= htmlspecialchars($foretag) ?></option>
        <?php endforeach; ?>
    </select>

    <input id="anchortext" type="text" placeholder="Skriv anchor text" />

    <input id="link" type="text" placeholder="Skriv en länk" />

    <!-- Competitors Section -->
    <div class="competitors-section">
        <h2>Competitors</h2>
        <div id="competitors">
            <div class="competitor">
                <input type="text" placeholder="Competitor Name" />
                <input type="url" placeholder="Competitor URL" />
            </div>
            <div class="competitor">
                <input type="text" placeholder="Competitor Name" />
                <input type="url" placeholder="Competitor URL" />
            </div>
            <div class="competitor">
                <input type="text" placeholder="Competitor Name" />
                <input type="url" placeholder="Competitor URL" />
            </div>
        </div>
    </div>

    <!-- Current Keywords Section -->
    <div class="keywords-section">
        <h2>Current Keywords</h2>
        <table>
            <thead>
                <tr>
                    <th>Keyword</th>
                    <th>Volume</th>
                    <th>Position</th>
                </tr>
            </thead>
            <tbody>
                <?php for ($i = 0; $i < 20; $i++): ?>
                <tr>
                    <td><input type="text" placeholder="Keyword" /></td>
                    <td><input type="number" placeholder="Volume" /></td>
                    <td><input type="number" placeholder="Position" /></td>
                </tr>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>

    <button id="send">Skapa texten</button>
</div>
</div>

</div>

<script>
const subcategories = {
    klader: [
        'mössor', 'handskar', 'skor', 'byxor', 'jackor', 
        'klänningar', 'skjortor', 't-shirts', 'overaller', 
        'strumpor', 'underkläder', 'tillbehör', 'smycken', 
        'skärp', 'vadderade kläder', 'badkläder', 'storlek anpassade kläder', 
        'arbetskläder', 'sportkläder', 'festkläder', 'sovkläder', 
        'vinterkläder', 'sommarkläder', 'regnkläder', 'underställ', 
        'ytterkläder', 'onesies', 'kläder för gravida', 'anpassade kläder'
    ],
    cyklar: [
        'mountainbike', 'racercykel', 'stadscykel', 'elcykel', 
        'barncykel', 'utflyktscykel', 'hobbycykel', 'sportcykel', 
        'cykelväskor', 'cykelhjälmar', 'cykeltröjor', 'cykelställ', 
        'tillbehör', 'cykelpedaler', 'cykelpump', 'cykelkärror', 
        'cykeldäck', 'cykelklockor', 'cykellyktor', 'cykelkorgar', 
        'cykelunderhåll', 'cykeltelefonfästen', 'fickor för cykel', 
        'cykelkedjor', 'väderbeständig cykelutrustning', 'cykeltillbehör för barn'
    ],
    mobler: [
        'soffor', 'bord', 'stolar', 'sängar', 'bokhyllor', 
        'förvaringslösningar', 'sängbord', 'skåp', 'matgrupper', 
        'kontorsmöbler', 'ute möbler', 'barnmöbler', 'industriella möbler', 
        'vintage möbler', 'designermöbler', 'äckergömmar', 
        'fällbara möbler', 'skärmar', 'dekorativa föremål', 
        'belysning', 'gardiner', 'mattor', 'trädgårdsmöbler', 
        'konsoler', 'kuddar', 'speglar', 'väggmonterade hyllor', 
        'stycken för små utrymmen'
    ],
    friskvard: [
        'gym', 'yoga', 'spa', 'kosttillskott', 'träningsredskap', 
        'välbefinnande', 'mental hälsa', 'meditation', 'mindfulness', 
        'cleansing', 'friskvårdskurser', 'personlig träning', 'kostrådgivning', 
        'fysträning', 'rehabilitering', 'zonterapi', 'massageterapi', 
        'pilates', 'avstressningsmetoder', 'hetvattensbad', 
        'naturopati', 'akupunktur', 'holistiska terapier', 
        'träningsprogram', 'hälsosam matlagning', 'sömnkvalitet', 
        'hälsokontroller', 'gruppträning'
    ],
    restauranger: [
        'pizzor', 'sushi', 'vegetariskt', 'snabbmat', 'fine dining', 
        'indisk mat', 'kinesisk mat', 'italiensk mat', 'mexikansk mat', 
        'bakverk', 'snacks', 'buffé', 'catering', 'frukostställen', 
        'bagerier', 'grillplatser', 'pubar', 'vinbarer', 
        'kaffehus', 'bufféluncher', 'food trucks', 'gatuvektorer', 
        'familjerestauranger', 'romantiska middagar', 'snabbservice', 
        'sittande restauranger', 'gastropubar'
    ],
    resor: [
        'flygresor', 'hotell', 'utflykter', 'paketresor', 'backpacking', 
        'äventyrsresor', 'sjöresor', 'all inclusive', 'weekendresor', 
        'road trips', 'camping', 'kryssningar', 'destination reseguider', 
        'resenärsforum', 'gruppresor', 'skidresor', 'strandresor', 
        'historiska resor', 'stadsresor', 'naturbesök', 
        'familjeresor', 'affärsresor', 'ensamresor', 
        'festivalsresor', 'ekologiska resor', 'tvärs över världen-resor'
    ],
    teknik: [
        'mobiler', 'datorer', 'tillbehör', 'smart-hus produkter', 
        'spelkonsoler', 'smart gadgets', 'robotik', 'AI-produkter', 
        'fotoutrustning', 'kabel och adapters', 'spelkonsoler', 
        'laptops', 'bordsdatorer', 'prylar för hemmet', 
        'smart TV', 'wearables', 'ljudutrustning', 
        'drönare', 'positioneringsteknologi', 'elektroniska kretsar', 
        'videokameror', 'gaming accessories', 'digitala plattor', 
        'hemunderhållning', 'mapping tools', 
        'internet och nätverk'
    ],
    skonhet: [
        'hudvård', 'smink', 'parfym', 'hårvård', 'skönhetsverktyg', 
        'ansiktsmasker', 'nagelvård', 'skönhetsbehandlingar', 
        'naturliga skönhetsprodukter', 'parabener-fria produkter', 
        'anti-aging produkter', 'solskydd', 'doftsprayer', 
        'hårtools', 'skäggvård', 'hudbehandlingar', 'make-up kit', 
        'manikyr och pedikyr', 'ekologiska produkter', 
        'skönhetstjänster', 'instrument för hudvård', 
        'merchandise från skönhetsmärken', 'skönhetsbloggar', 
        'social medier-baserad skönhet', 'skönhetsutbildningar'
    ],
    utbildning: [
        'kurser', 'workshops', 'onlineutbildningar', 'studielitteratur', 
        'språkkurser', 'yrkesutbildningar', 'barnutbildningar', 
        'skolmaterial', 'hemundervisning', 'lektioner', 
        'färdighetsutveckling', 'certifieringsprogram', 'mentorprogram', 
        'video tutorials', 'självstudiekurser', 'gruppstudier', 
        'examenstjänster', 'universitetsprogram', 'konferenser', 
        'seminarier', 'lärarutbildningar', 'forskning och akademiska resurser', 
        'bakgrundslitteratur', 'appar för studier', 'digitala klassrum', 
        'hjälp med läxor', 'utbildningsresurser'
    ],
    finans: [
        'sparande', 'låna', 'investeringar', 'budgetering', 
        'skatt', 'personlig ekonomi', 'aktier', 'fonder', 
        'kryptovaluta', 'finansiell rådgivning', 'pensionsplanering', 
        'livförsäkring', 'hemförsäkring', 'bilförsäkring', 
        'finansiella appar', 'skuldkonsolidering', 'lån för studier', 
        'fastighetsinvesteringar', 'banker och kreditinstitut', 
        'finansiella strategier', 'planering för framtiden', 
        'skatteplanering', 'digitala plånböcker', 'utgiftshantering',
        'finansiella utbildningar', 'investeringstrender'
    ],
    underhallning: [
        'filmer', 'spel', 'musik', 'teater', 'konserter', 
        'podcasts', 'tv-serier', 'böcker', 'evenemang', 
        'utställningar', 'festivaler', 'videospel', 'live-streaming', 
        'skådespeleri', 'seriemaraton', 'komedi', 'dramatiseringar', 
        'dokumentärer', 'spelnatt', 'musikaliska evenemang', 
        'konstnärliga föreställningar', 'filmfestivaler', 
        'virtual reality upplevelser', 'amatörteater', 
        'samtida konst', 'kulturella utbyten'
    ],
    bilar: [
        'nya bilar', 'begagnade bilar', 'tillbehör', 
        'reparationstjänster', 'bilmotorer', 'däck och fälgar', 
        'bilvård', 'verktyg för bilvård', 'bilbatterier', 
        'lastbilar', 'SUV', 'sportbilar', 'elbilsladdare', 
        'bilfinansiering', 'bilsäkerhet', 'extra utrustning', 
        'bilförsäkring', 'bilsalg', 'biltest', 
        'tillbehör för husvagnar', 'bilrekonditionering', 
        'grepp och mellanreglag', 'auto365', 'agenser', 
        'bilar för familjer', 'restaurering av gamla bilar'
    ],
    fastigheter: [
        'lägenheter', 'hus', 'kommersiella fastigheter', 
        'hyresrätter', 'sälja hus', 'investeringar i fastigheter', 
        'överlåtelser', 'fastighetsplanering', 'fastighetsbehandling', 
        'renovering', 'fastighetsmäklare', 'lokala marknader', 
        'fastighetsundersökningar', 'expansionsmöjligheter', 
        'lagar och regler', 'urban utveckling', 'husrenovering', 
        'automation av fastigheter', 'äldre fastigheter', 
        'reparation och underhåll', 'öppen visning', 
        'fastighetsbesiktning', 'webbplatser för fastigheter', 
        'fastighetsportaler', 'bostadsmarknadens nyheter'
    ],
    jewelry: [
        'ringar', 'örhängen', 'smycken i ädelmetall', 
        'handgjorda smycken', 'barntillverkning', 'halssmycken', 
        'armband', 'accessoarer', 'personliga smycken', 
        'smycken till bröllop', 'klädesmycken', 'smycken för vardagligt bruk', 
        'smycken med ädelstenar', 'vintage smycken', 'guld och silver', 
        'designer smycken', 'smycken med gravyr', 
        'tematiska smycken', 'geografisk inspiration', 
        'festliga smycken', 'esoteriska smycken', 
        'smycken som investering', 'fashion jewelry', 
        'trendiga smycken', 'inspirerande smycken'
    ],
    livsmedel: [
        'färskvaror', 'konserver', 'snacks', 'drycker', 
        'specialkost', 'glutenfria produkter', 'vegetariska alternativ', 
        'veganprodukter', 'kryddor', 'dietprodukter', 
        'frysmat', 'mathantering', 'ekologiska varor', 
        'hemgjord mat', 'ready-to-eat måltider', 'gourmetprodukter', 
        'länders kök', 'frukt och grönsaker', 
        'köttprodukter', 'mejeriprodukter', 'bagerivaror', 
        'vatten och drycker', 'förpackningar', 'matlagningstips',
        'matprogram', 'matbloggar'
    ],
    konst: [
        'målningar', 'skulpturer', 'fotografi', 'konstverk', 
        'digital konst', 'konstböcker', 'konstsmycken', 
        'performancekonst', 'konstutställningar', 'gjorda i hemmet', 
        'kollektioner', 'konsttryck', 'grafiska verk', 
        'mixed media', 'modern konst', 'historiska målningar', 
        'jobba med konstnärer', 'konstprojekt', 
        'mediemix', 'konst från olika kulturer', 
        'konstnärligt samarbete', 'konst och teknologi', 
        'konstvandringar', 'konstlärare'
    ],
    sport: [
        'sportkläder', 'utrustning', 'tillbehör', 'sportevenemang', 
        'gymnastik', 'individualsport', 'lagidrott', 
        'extrem sport', 'vattensporter', 'vintersporter', 
        'fitnessklasser', 'utrustning för självförsvar', 
        'tränare', 'sportlig coaching', 'sporter för barn', 
        'fitnessspårning', 'sportnutrition', 
        'hälsoanalyser', 'konkurrensprogram', 'utmaningsgrupper', 
        'resor för sport', 'medlemskap inom sport', 
        'livsstilsplaner', 'sportevenemang i världen', 
        'skolidrott'
    ],
    musik: [
        'instrument', 'skivor', 'konserter', 'musikutrustning', 
        'noter', 'skivföretag', 'musikproducenter', 'musikutbildningar', 
        'vinylskivor', 'streaming-tjänster', 'musiktävlingar', 
        'artister', 'musikaliska stilar', 'musikalisksäskedjor', 
        'konsertresor', 'musiksamlingar', 'musikalisk programvara', 
        'studior', 'ld-forms', 'konsertarrangemang', 
        'gallerier för musik', 'musikaliska spännande evenemang', 
        'studera musik', 'musik och livsstil'
    ],
    diy: [
        'verktyg', 'material', 'guideböcker', 'inspirationsprojekt', 
        'hemmafix', 'trädgårdsarbete', 'renovering', 
        'handarbete', 'mobbning', 'installationsprojekt', 
        'konstprojekt', 'skapa egna produkter', 'wedding DIY', 
        'renoveringsidéer', 'säsongsprojekt', 
        'designade kläder', 'införskaffa och anpassa', 
        'hemesourcing', 'vidtagande åberopande', 
        'konstruera med barn', 'stolsarbeslag', 
        'smycken', 'interiördesign', 'kollektioner', 
        'projektplanering'
    ],
    barnprodukter: [
        'leksaker', 'kläder', 'barnmöbler', 'skolmaterial', 
        'barnsäkra produkter', 'barnvagnar', 'speldatorer', 
        'barnkurser', 'skötselprodukter', 'barnhem', 
        'familjeaktiviteter', 'utbildningsverktyg', 'barnkultur', 
        'böcker för barn', 'barnkalas', 'barnens videoserier', 
        'barnens utställningar', 'lek och lärande', 
        'barns kreativitet', 'handgjorda barnprodukter', 
        'barnens favoriter', 'sparande för barn', 
        'personlig kontakt', 'barnsuri'
    ],
    hemelektronik: [
        'tv-apparater', 'ljudsystem', 'kökstillbehör', 
        'smart gadgets', 'smart hem-lösningar', 'projektorer',
        'konsolspel', 'gaming-tillbehör', 'hemunderhåll',
        'tv-antenn', 'streaming-enheter', 'smart telefoner', 
        'handsfree-enheter', 'surfplattor', 
        'hemtjänst elektroniska produkter', 'elektroniska lås', 
        'skydd mot husträning', 'terminologiska system', 
        'elektroniska enheter', 'hälsorelaterade enheter', 
        'online order', 'automatiserade funktioner', 
        'konfigurationsguider', 'smart teknologi'
    ],
    boker: [
        'fiktion', 'facklitteratur', 'biografier', 
        'barnböcker', 'e-böcker', 'ljudböcker', 
        'berättelse och poesi', 'klassisk litteratur', 'lustiga berättelser', 
        'sci-fi och fantasylitteratur', 'historiska verk', 
        'självhjälp', 'inspirerande och motiverande litteratur',
        'kokböcker', 'biografiska skildringar', 
        'reseskildringar', 'barnlitteratur och barnböcker', 
        'författares biografier', 'litterära diskussioner', 
        'tidskrifter', 'noveller', 'antologier', 
        'grundläggande litteratur', 'ackrediteringsarbeten', 
        'foyerer', 'kollektioner av noveller'
    ],
    klimat: [
        'solpaneler', 'miljöprodukter', 'återvinning', 
        'grön teknik', 'energi-effektivisering', 'koldioxidneutral',
        'ekologiska produkter', 'hållbara lösningar', 
        'transportlösningar', 'återuduggbara produkter', 
        'klimatvänlig kost', 'klimatförändring', 
        'cirkulär ekonomi', 'sociala initiativ', 
        'klimatåtgärder', 'globalt engagemang', 
        'hållbarhetsprogram', 'klimatstrategier', 
        'medveten livsstil', 'skydd för sjöar och hav', 
        'naturvård', 'ekosystem', 'växtliv', 
        'fjällnäring', 'naturvårdsprojekt', 
        'vattenskydd'
    ],
    blommor: [
        'inomhusväxter', 'trädgårdsväxter', 'snittblommor', 
        'planteringsmaterial', 'trädgårdsverktyg', 
        'trädgårdsdesign', 'utomhusplantering', 'fröer',
        'blommor för alla tillfällen', 'blommor till bröllop', 
        'blommor som gåvor', 'klippblommor', 
        'bryggblommor', 'blommor med doft', 
        'trädgårdar och snittblommor', 'komposition och design', 
        'teknik för att växa', 'blomsterarrangemang', 
        'growing your own', 'blommor i hjärtat', 
        'trädplanteringsprogram', 'blommor för vår och sommar', 
        'botaniska trädgårdar', 'terapeutiska blommor'
    ],
    hantverk: [
        'material', 'verktyg', 'inspiration', 'kurser',
        'handgjord', 'hantverksaffärer', 'historiska hantverk', 
        'konstverk', 'verk av lokalproducerat', 
        'förpackningar', 'papper och pappersprodukter', 
        'snickeri', 'hälsa och säkerhet', 
        'skulptering', 'textilkonst', 'färger och smycken', 
        'designade hobbysystem', 'design och skräddarsydda artiklar', 
        'skaparens handling', 'bekväma tillbehör', 
        'små och stora projekt', 'styra hallar', 
        'klä upp fågelholkar', 'samlar och delger', 
        'miljövänliga konstformer', 'färga och ha kul'
    ],
    presenter: [
        'presentlådor', 'personliga gåvor', 'upplevelser', 
        'säsongsprodukter', 'gadgets', 'handgjorda presenter', 
        'böcker', 'presentkort', 'bryllupsgåvor', 
        'firande och familjeaktiviteter', 'specialiserade presentationer',
        'skapa skräddarsydda gåvor', 'naturliga produkter', 
        'episka presenter', 'kreativ i tydlig utförande', 
        'presenter för alla', 'indelning', 
        'skapa upplevelser med gåvor', 'personlig touch', 
        'geniala idéer', 'presentprogram', 
        'merchandise', 'inspiration', 
        'trendiga produkter', 'synergieffekter'
    ],
    resprylar: [
        'väskor', 'accessoarer', 'kläder för resor', 
        'reseutrustning', 'reseplaner', 'hotellbokningar', 
        'flygresor', 'resebloggar', 'tips om resor', 
        'designtips och inspiration', 'digitala plånböcker', 
        'info om flygplatser', 'resehandböcker', 
        'transport', 'reseangebote', 'reseanpassningar',
        'kanaler med bra mat', 'familjeresor', 'destinationer',
        'bilder av resor', 'gameresor', 'resa med barn'
    ],
    kurser: [
        'språkkurser', 'yrkesutbildningar', 'hobbykurser', 
        'onlinekurser', 'personlig utveckling', 
        'konstkurser', 'musikutbildningar', 'tekniska kurser', 
        'programmering', 'designprogram', 'störningar', 
        'platser för utbildning', 'skolor', 'social kompetens', 
        'ledarskapsutbildning', 'cykelutbildning', 
        'praktiska kurser', 'fortsatta studier', 
        'arbeidskurser', 'skryptande kurser', 
        'utbildningsböcker', 'utökningskurser', 
        'utbildning av instruktörer', 'typografikurser', 
        'prissättningar'
    ],
};

const kategoriSelect = document.getElementById('kategori');
const subkategoriSelect = document.getElementById('subkategori');

kategoriSelect.addEventListener('change', function() {
    const selectedKategori = this.value;
    
    // Clear the subcategory options
    subkategoriSelect.innerHTML = '<option value="">Underkategori</option>';
    
    // Populate subcategories based on selected kategori
    if (subcategories[selectedKategori]) {
        subcategories[selectedKategori].forEach(function(subcategory) {
            const option = document.createElement('option');
            option.value = subcategory;
            option.textContent = subcategory;
            subkategoriSelect.appendChild(option);
        });
    }
});

const messagesDiv = document.getElementById('messages');
const sendButton = document.getElementById('send');

sendButton.addEventListener('click', async () => {
    const kategori = kategoriSelect.value;
    const subkategori = subkategoriSelect.value;
    const rubriker = document.getElementById('rubriker').value;
    const sprak = document.getElementById('sprak').value;
    const foretag = document.getElementById('foretags').value;
    const anchortext = document.getElementById('anchortext').value;
    const link = document.getElementById('link').value;

   // Skapa en huvudprompt med en mer sammanhängande formulering
let prompt = "Skriv en SEO-optimerad text i strukturerad kod för en webbplats. Använd <h2> för rubriker och <p> för stycken, men ta bort ```html ```";

if (kategori) {
    prompt += `Texten ska handla om ${kategori} `;
}
if (subkategori) {
    prompt += `med fokus på ${subkategori}. `;
}
if (rubriker) {
    prompt += `Texten ska totalt innehålla ${rubriker} rubriker och ska skrivas på ${sprak}. `;
}
if (foretag) {
    prompt += `Hela texten ska fokusera på att marknadsföra företaget ${foretag}. `;
}
if (anchortext && link) {
    prompt += `I texten vill jag ha max 1 länk (${link})  som är "${anchortext}". `;
}

prompt += "Jag vill att du skriver hela texten på ett snyggt sätt, inget onödigt, ska endast handla om det jag skrivit.";

// Exempel på hur prompten kan se ut
console.log(prompt);

    // Clear previous messages
    messagesDiv.innerHTML = '';

    const userMessage = document.createElement('div');
    userMessage.style.display = 'none'; // Hide user message

    messagesDiv.appendChild(userMessage); 

    try {
        const response = await fetch('http://localhost:3000/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: prompt })
        });

        

        const data = await response.json();
        if (data.response) {
            const assistantMessage = document.createElement('div');
            assistantMessage.classList.add('message', 'assistant-message');

            const assistantText = data.response.replace(/^(.*?):\s*/, ""); // Remove any prefix
            assistantMessage.innerHTML = `<h2></h2><p>${assistantText}</p>`;
            
            messagesDiv.appendChild(assistantMessage);
            messagesDiv.scrollTop = 0;
        }
    } catch (error) {
        console.error('Error:', error);
    }
});
</script>


<script>
    document.getElementById("send").addEventListener("click", function() {
        const loadingScreen = document.querySelector(".loadingscreen");
        const messageBg = document.getElementById('messages');

        loadingScreen.style.display = 'flex';

        requestAnimationFrame(() => {
            loadingScreen.style.opacity = 1;
        });

        setTimeout(() => {
            loadingScreen.style.opacity = 0;
            messageBg.style.backgroundImage = 'none';
        }, 6000);

        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 7500);
    });
</script>

</body>
</html>