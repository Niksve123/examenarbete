<?php
// Database credentials
$host = 'mysql1-1.hostek.se'; // MySQL Server
$dbname = 'dbs127485';        // Database Name
$username = 'udmybs471543';   // User Name
$password = 'Vi5xyX8.rAJZ0cnQ'; // Password

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Close the connection (optional, usually left open for further queries)
// $conn->close();
?>